/*
 Copyright (C) 2007 ha55ii, http://dan-ball.jp/
 The games source code use is prohibition.
*/
var aa = 0
  , k = 400
  , m = 300
  , ba = k / 2
  , ca = m / 2
  , n = 0
  , t = 0
  , da = 0
  , ea = 0
  , fa = 3
  , ga = ""
  , ha = 0
  , ia = 0
  , la = 0
  , ma = 0
  , na = 0
  , pa = 0
  , qa = 0
  , sa = new ra
  , ta = new ra
  , ua = new ra
  , va = new ra
  , wa = new ra
  , xa = Array(fa)
  , ya = Array(fa)
  , za = Array(fa)
  , Aa = new ra
  , Ba = new ra
  , Ca = new ra
  , Da = new ra
  , Ea = new ra
  , Fa = new ra
  , Ga = new ra
  , Ha = 0;
function Ia(a) {
    if (0 == Ha) {
        a && (ga = a);
        Ja(Ka);
        La.width = k;
        La.height = m;
        for (a = 0; 513 > a; a++)
            u[a] = Array(2);
        for (a = 0; 512 > a; a++) {
            var c = 360 * a / 512 * Ma / 180;
            u[a][0] = Math.cos(c);
            u[a][1] = Math.sin(c)
        }
        u[a][0] = u[0][0];
        u[a][1] = u[0][1];
        for (a = 0; 256 > a; a++)
            Oa[a] = !1,
            Pa[a] = !1,
            Qa[a] = !1,
            w[a] = 0,
            x[a] = 0;
        for (a = 0; 10 > a; a++)
            w[48 + a] = 48 + a;
        for (a = 0; 9 > a; a++)
            x[49 + a] = 33 + a;
        for (a = 0; 4 > a; a++)
            w[37 + a] = 37 + a;
        for (a = 0; 4 > a; a++)
            x[37 + a] = 37 + a;
        w[13] = x[13] = 13;
        w[16] = x[16] = 16;
        w[17] = x[17] = 17;
        w[18] = x[18] = 18;
        w[32] = x[32] = 32;
        w[186] = 58;
        x[186] = 42;
        w[187] = 59;
        x[187] = 43;
        w[188] = 44;
        x[188] = 60;
        w[189] = 45;
        x[189] = 61;
        w[190] = 46;
        x[190] = 62;
        w[191] = 47;
        x[191] = 63;
        w[192] = 64;
        x[192] = 96;
        w[219] = 91;
        x[219] = 123;
        w[220] = 92;
        x[220] = 124;
        w[221] = 93;
        x[221] = 125;
        w[222] = 94;
        x[222] = 126;
        w[226] = 92;
        x[226] = 95;
        w[58] = 58;
        x[58] = 42;
        w[59] = 59;
        x[59] = 43;
        w[173] = 45;
        x[173] = 61;
        w[64] = 64;
        x[64] = 96;
        w[160] = 94;
        x[160] = 126;
        var b;
        for (a = 0; 1024 > a; a++)
            Ra[a] = a / 1024;
        for (a = 0; 1024 > a; a++)
            c = y(1024 * Math.random()),
            b = Ra[a],
            Ra[a] = Ra[c],
            Ra[c] = b;
        Sa = y(1024 * Math.random()) & 1023;
        Ta = y(512 * Math.random()) | 1;
        for (a = 0; a < k * m; a++)
            z[a] = 0;
        for (a = 0; a < k * m * 4; a++)
            Ua[a] = 255;
        Va.h("font.gif", 8, 16);
        sa.h("panda.gif");
        ta.h("title.gif");
        ua.h("title2.gif");
        Wa(va, 400, 300);
        wa.h("coconut.gif");
        for (a = 0; a < fa; a++)
            xa[a] = new ra,
            xa[a].h("image" + a + ".gif"),
            ya[a] = new ra,
            ya[a].h("st" + a + ".gif"),
            za[a] = new ra,
            za[a].h("obj" + a + ".gif");
        Aa.h("flower0.gif");
        Ba.h("flower1.gif");
        Ca.h("flower2.gif");
        Da.h("grass.gif");
        Ea.h("grass2.gif");
        Fa.h("clock.gif");
        Ga.h("ef.gif");
        Xa() ? Ha-- : Ha++
    }
    if (1 == Ha) {
        Ya(Va.$);
        Ya(sa);
        Ya(ta);
        Ya(ua);
        Ya(wa);
        for (a = 0; a < fa; a++)
            Ya(xa[a]),
            Ya(ya[a]),
            Ya(za[a]);
        Ya(Aa);
        Ya(Ba);
        Ya(Ca);
        Ya(Da);
        Ya(Ea);
        Ya(Fa);
        Ya(Ga);
        0 != Za ? $a(Ia, ab()) : Ha++
    }
    if (2 == Ha) {
        A(bb, 0, 0, 0);
        A(B, 0, 0, 0);
        A(cb, 0, 1, 0);
        db[0] = new eb(1,160,160,0,0,0,0,0,0.5,0,0.5,0,0,0,0,0.06,0.06,1,0,1,0,1.2,0,1.2,0,0.85,0,1,1,1,0,1,2,1,6,1,0,2,255,255,0,255,255,255,0,0,0,64,64,64);
        db[1] = new eb(1,40,40,5,15,0,0,0,0.5,0,0.5,0,0,0,0,0,0,1,0,1,0,1.1,0,1.1,0,0.85,0,1,1,1,0,0,2,1,6,1,0,2,255,255,255,255,0,0,0,0,0,64,64,64);
        db[2] = new eb(1,40,40,5,15,0,0,0,0.5,0,0.5,0,0,0,0,0,0,1,0,1,0,1.5,0,1.5,0,0.85,0,1,1,1,0,0,2,1,6,1,0,2,255,255,255,255,0,0,0,0,0,64,64,64);
        db[3] = new eb(1,40,40,5,15,0,0,0,0.5,0,0.5,0,0,0,0,0,0,1,0,1,0,2.4,0,2.4,0,0.85,0,1,1,1,0,0,2,1,6,1,0,2,255,255,255,255,0,0,0,0,0,64,64,64);
        db[4] = new eb(1,25,30,5,15,0,0,0,0,0,0,0.06,0,0.08,0,0,0,0,0.1,0.1,0.2,0,0,0,0,1,0,0.96,0,0,2,0,1,0,5,3,0,2,255,255,160,255,0,0,0,0,0,0,32,32);
        db[5] = new eb(3,20,35,5,15,0,0,0.5,0,0.7,0,0.12,0,0.12,0,0,0,0.4,0,0.6,0,0,0,0,0,1,0,0.96,0,2,3,0,1,1,4,3,0,1,140,255,80,200,0,0,0,0,0,0,32,32);
        db[6] = new eb(1,80,80,0,80,0,0,0,0,0,0,0,0.01,0,0.01,0,0,0.1,0.5,0.1,0.5,0,0,0,0,1,0,0.8,0,0,1,0,0,0,5,3,0,3,100,100,100,180,0,0,0,0,0,32,32,32);
        db[7] = new eb(1,20,25,0,20,0,10,0,0.1,0,0.5,0.01,0,0.02,0,0,0,0.1,0,0.2,0,1.6,0,1.8,0,0.98,0,0.98,0,1,2,0,2,1,4,1,0,1,128,98,0,60,0,0,0,0,32,32,32,32);
        db[8] = new eb(2,20,25,0,10,0,0,0,0.1,0,0.2,0.03,-0.01,0.04,-0.02,0,0,0,0.2,0.1,0.3,0,0,0,0,1,0.001,0.98,0,1,2,0,0,0,5,1,0,2,0,130,0,180,0,0,0,0,32,32,32,32);
        db[9] = new eb(1,40,50,0,40,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,2,0,3,0,1,0,1,0,0,0,0,1,1,6,1,0,5,230,240,255,200,0,0,0,0,64,64,64,64);
        db[10] = new eb(1,80,80,10,10,0,0,0,0,0,0,0,0.19,0,0.19,0,0,0.2,1.8,0.2,1.8,0.2,0.2,0.2,0.2,1,-0.002,1,0,0,1,0,1,0,5,1,0,2,255,255,255,255,0,0,0,0,0,32,32,32);
        db[11] = new eb(8,90,110,5,15,80,80,0.3,0.2,0.3,0.2,0.2,0,0.2,0,0,0,0.1,0,0.1,0,1.2,0,1.8,0,1,-0.004,0.98,0,2,3,0,1,0,2,1,1,2,255,255,0,255,0,0,255,255,0,32,32,32);
        db[12] = new eb(8,90,110,10,30,80,80,0.01,0,0.01,0,0.25,0,0.25,0,0,0,0.4,0.4,0.6,0.6,1.8,1.8,2.2,2.2,1,-0.002,0.96,0,2,3,0,1,1,4,1,1,2,0,255,0,255,255,0,255,255,0,32,32,32);
        db[13] = new eb(8,90,110,5,10,80,80,0.9,0,0.9,0,0.3,0,0.3,0,0,0,0.5,2,0.5,2,0.5,0.5,0.5,0.5,1,-0.002,0.97,0,2,3,0,1,0,5,1,1,2,255,0,0,255,0,255,255,255,0,32,32,32);
        C.h();
        a = jb;
        c = 1 / Math.tan(0.5 * kb);
        a.t = c / (k / m);
        a.u = 0;
        a.v = 0;
        a.I = 0;
        a.w = 0;
        a.m11 = c;
        a.m12 = 0;
        a.m13 = 0;
        a.A = 0;
        a.m21 = 0;
        a.m22 = -1;
        a.m23 = -1;
        a.B = 0;
        a.m31 = 0;
        a.m32 = -0;
        for (a = a.m33 = 0; 1E4 > a; a++)
            D[a] = new E,
            lb[a] = new E;
        mb()
    }
}
var ob = new nb
  , jb = new nb
  , D = Array(1E4)
  , lb = Array(1E4)
  , F = 0
  , G = Array(1E4)
  , bb = new E
  , B = new E
  , cb = new E
  , kb = 0.785398175
  , pb = 0
  , qb = 0
  , H = 0
  , rb = 1
  , sb = 0
  , tb = 0
  , I = new ub
  , vb = 5
  , wb = 8;
function ub() {
    this.Y = this.J = this.H = this.n = this.a = this.T = this.d = 0;
    this.l = new E;
    this.dir = new E;
    this.va = this.F = 0;
    this.oa = new E
}
ub.prototype.h = function() {
    var a, c, b, d = new E;
    vb = 5;
    wb = 8;
    this.d = Array(vb);
    this.T = Array(vb);
    this.a = Array(wb);
    this.n = Array(wb);
    this.Y = Array(wb);
    for (a = 0; a < vb; a++)
        this.d[a] = new E;
    for (a = 0; a < vb; a++)
        this.T[a] = new E;
    for (a = 0; a < wb; a++)
        this.a[a] = new E;
    for (a = 0; a < wb; a++)
        this.n[a] = new E;
    this.H = Array(this.d.length * (this.d.length - 1));
    this.J = Array(this.a.length * this.d.length);
    for (a = 0; a < this.H.length; a++)
        this.H[a] = new xb;
    for (a = 0; a < this.J.length; a++)
        this.J[a] = new xb;
    A(this.d[0], 0, 1, 0);
    A(this.d[1], -0.3, 0, -0.45);
    A(this.d[2], 0.3, 0, -0.45);
    A(this.d[3], 0.3, 0, 0.45);
    A(this.d[4], -0.3, 0, 0.45);
    for (a = b = 0; a < this.d.length; a++)
        for (c = a + 1; c < this.d.length; c++)
            J(d, this.d[a], this.d[c]),
            this.H[b++].set(a, c, d.O());
    A(this.a[0], -0.3, 0, -0.45);
    A(this.a[1], 0.3, 0, -0.45);
    A(this.a[2], -0.3, 0, 0.45);
    A(this.a[3], 0.3, 0, 0.45);
    A(this.a[4], -0.3, 0.7, -0.45);
    A(this.a[5], 0.3, 0.7, -0.45);
    A(this.a[6], -0.3, 0.7, 0.45);
    A(this.a[7], 0.3, 0.7, 0.45);
    b = 0;
    for (a = this.a.length - 1; 0 <= a; a--)
        for (c = 0; c < this.d.length; c++)
            J(d, this.a[a], this.d[c]),
            this.J[b++].set(a, c, d.O());
    for (a = 0; a < this.d.length; a++)
        this.T[a].set(this.d[a]);
    for (a = 0; a < this.a.length; a++)
        this.n[a].set(this.a[a])
}
;
ub.prototype.move = function(a) {
    var c, b = new E;
    if (1 == a) {
        a = yb();
        null != a && zb && 0 < this.Y[0] + this.Y[1] + this.Y[2] + this.Y[3] && (this.dir.y = 0,
        K(this.dir),
        a.y = this.d[1].y,
        J(b, a, this.d[1]),
        K(b),
        b.add(this.dir),
        K(b),
        Ab(b, b, 0.03),
        this.d[1].add(b),
        a.y = this.d[2].y,
        J(b, a, this.d[2]),
        K(b),
        b.add(this.dir),
        K(b),
        Ab(b, b, 0.03),
        this.d[2].add(b));
        Bb(this.d[0], this.T[0], 0.01, 0.99);
        for (a = 1; a < this.d.length; a++)
            Bb(this.d[a], this.T[a], -0.01, 0.99);
        for (a = 0; a < this.a.length; a++)
            Bb(this.a[a], this.n[a], -0.01, 0.99);
        for (a = 0; a < this.H.length; a++)
            Cb(this.d[this.H[a].ha], this.d[this.H[a].ia], this.H[a].O, 0.5);
        for (a = 0; a < this.J.length; a++)
            Cb(this.a[this.J[a].ha], this.d[this.J[a].ia], this.J[a].O, 0.1);
        for (a = 0; 4 > a; a++)
            -0.1 > this.a[a].x && (A(b, -0.1, 0, 0),
            C.create(0, Db, this.a[a], b)),
            this.a[a].x > L.e - 1 && (A(b, 0.1, 0, 0),
            C.create(0, Db, this.a[a], b)),
            -0.1 > this.a[a].z && (A(b, 0, 0, -0.1),
            C.create(0, Db, this.a[a], b)),
            this.a[a].z > L.g - 1 && (A(b, 0, 0, 0.1),
            C.create(0, Db, this.a[a], b)),
            -0.4 > this.a[a].x && (A(b, -0.1, 0, 0),
            C.create(0, Eb, this.a[a], b)),
            this.a[a].x > L.e - 0.7 && (A(b, 0.1, 0, 0),
            C.create(0, Eb, this.a[a], b)),
            -0.4 > this.a[a].z && (A(b, 0, 0, -0.1),
            C.create(0, Eb, this.a[a], b)),
            this.a[a].z > L.g - 0.7 && (A(b, 0, 0, 0.1),
            C.create(0, Eb, this.a[a], b));
        for (a = 0; a < this.a.length; a++)
            this.Y[a] = Fb(this.a[a], this.n[a], 0.9);
        for (a = 2; 4 > a; a++)
            if (0 != this.Y[a] && (J(b, this.n[a], this.a[a]),
            !(0.01 > Gb(b)))) {
                if (3 > Hb(10)) {
                    var d = new E;
                    d.set(this.a[a]);
                    d.y += 0.1;
                    K(b);
                    b.p(0.1);
                    C.create(0, Ib, d, b)
                }
                d = Jb(this.a[a]);
                1 == d && 4 > Hb(10) ? C.create(0, Kb, this.a[a], null) : 2 == d && 4 > Hb(10) ? C.create(0, Lb, this.a[a], null) : 3 == d && 1 > Hb(10) && (b.set(this.a[a]),
                b.y = -0.2,
                C.create(0, Mb, b, null))
            }
    }
    A(this.l, 0, 0, 0);
    for (a = 0; a < this.d.length; a++)
        this.l.add(this.d[a]);
    Nb(this.l, this.d.length);
    a = new E;
    d = new E;
    Ob(a, this.d[1], this.d[2]);
    Ob(d, this.d[4], this.d[3]);
    J(this.dir, a, d);
    K(this.dir);
    this.F = 6;
    this.va = 0.5;
    a = y(0 < this.l.x - this.F ? this.l.x - this.F : 0);
    for (var d = y(this.l.x + this.F < L.e - 1 ? this.l.x + this.F : L.e - 1), g = y(this.l.z + this.F < L.g - 1 ? this.l.z + this.F : L.g - 1), f = y(0 < this.l.z - this.F ? this.l.z - this.F : 0); f < g; f++)
        for (var e = a; e < d; e++) {
            c = e + 0.5 - this.l.x;
            var h = -this.l.y
              , l = f + 0.5 - this.l.z
              , p = Math.sqrt(c * c + h * h + l * l);
            p > this.F || (A(b, c, h, l),
            K(b),
            0.5 > Pb(b, this.dir) || (c = f * L.e + e,
            p = 5 / p / p,
            p *= (Pb(b, this.dir) - 0.5) / 0.5 * ((Pb(b, this.dir) - 0.5) / 0.5),
            L.r[1][c] = 1 > L.r[1][c] + p ? L.r[1][c] + p : 1))
        }
    this.F = 5;
    this.va = 0.9;
    b.set(this.l);
    b.y = 2 < b.y ? 0.1 * (b.y - 2) + 0.9 * B.y : 0.9 * B.y;
    A(B, b.x, b.y, b.z);
    A(bb, b.x, b.y + 8, b.z + 10)
}
;
ub.prototype.k = function() {
    H = pb = 1;
    var a, c = new E, b = new E, d = new E, g = new E, f = new E, e = new E, h = new E;
    for (a = 0; 8 > a; a++)
        b.add(this.a[a]);
    Nb(b, 8);
    d.add(this.a[0]);
    d.add(this.a[1]);
    d.add(this.a[4]);
    d.add(this.a[5]);
    Nb(d, 4);
    g.add(this.a[2]);
    g.add(this.a[3]);
    g.add(this.a[6]);
    g.add(this.a[7]);
    Nb(g, 4);
    J(h, g, d);
    K(h);
    for (a = 4; 8 > a; a++)
        e.add(this.a[a]);
    Nb(e, 4);
    for (a = 0; 4 > a; a++)
        c.add(this.a[a]);
    Nb(c, 4);
    e.sub(c);
    K(e);
    Qb(f, e, h);
    K(f);
    b.y += 0.2;
    d.y += 0.2;
    g.y += 0.2;
    Rb(b, f, e, h, 0, 0, 0.2, 0.4, 0.35, 0.6, 15658734);
    Rb(d, f, e, h, 0, 0.1, 0, 0.5, 0.3, 0.1, 2105376);
    Rb(d, f, e, h, 0, 0, -0.4, 0.4, 0.3, 0.2, 15658734);
    Rb(d, f, e, h, 0.2, 0.4, -0.3, 0.1, 0.1, 0.1, 2105376);
    Rb(d, f, e, h, -0.2, 0.4, -0.3, 0.1, 0.1, 0.1, 2105376);
    c.set(this.a[0]);
    c.y += 0.2;
    Rb(c, f, e, h, 0, 0, 0, 0.2, 0.2, 0.2, 2105376);
    c.set(this.a[1]);
    c.y += 0.2;
    Rb(c, f, e, h, 0, 0, 0, 0.2, 0.2, 0.2, 2105376);
    c.set(this.a[2]);
    c.y += 0.2;
    Rb(c, f, e, h, 0, 0, 0, 0.2, 0.2, 0.2, 2105376);
    c.set(this.a[3]);
    c.y += 0.2;
    Rb(c, f, e, h, 0, 0, 0, 0.2, 0.2, 0.2, 2105376);
    Rb(g, f, e, h, 0, 0, 0.5, 0.15, 0.15, 0.1, 2105376);
    a = new E;
    Ab(a, f, 0.4);
    f = new E;
    Ab(f, e, 0.3);
    Ab(c, h, -0.61);
    d.add(c);
    F = 0;
    Ob(c, d, a);
    c.add(f);
    M(c, 0, 0);
    J(c, d, a);
    c.add(f);
    M(c, 32, 0);
    J(c, d, a);
    c.sub(f);
    M(c, 32, 24);
    Ob(c, d, a);
    c.sub(f);
    M(c, 0, 24);
    Sb(sa, 15658734);
    H = pb = 0
}
;
function Tb() {
    var a = I, c, b = new E, d = new E;
    A(d, 0, 0, 0);
    for (c = 0; 4 > c; c++)
        d.add(a.a[c]);
    Nb(d, 4);
    var g = 1E3;
    A(b, 0, 0, 0);
    for (c = 0; c < N.b; c++)
        if (!1 != N.c[c]) {
            var f = d.x - N.a[c].x
              , e = d.z - N.a[c].z
              , h = f * f + e * e;
            g > h && (g = h,
            b.x = f,
            b.z = e)
        }
    K(b);
    a.oa.p(0.99);
    b.p(0.01);
    a.oa.add(b);
    g = new E;
    g.set(a.oa);
    g.y = -0.8;
    K(g);
    for (c = F = 0; 4 > c; c++)
        J(b, a.a[c], d),
        K(b),
        f = Pb(g, b),
        0 > f && (f = 0),
        Ab(b, g, 20 * f),
        b.add(a.a[c]),
        O(b);
    for (c = 4; 8 > c; c++)
        O(a.a[c]);
    qb = pb = 1;
    P(1, 0, 3, 16711680);
    P(3, 0, 2, 16711680);
    P(4, 5, 6, 16711680);
    P(6, 5, 7, 16711680);
    P(5, 4, 1, 65280);
    P(1, 4, 0, 65280);
    P(6, 7, 2, 65280);
    P(2, 7, 3, 65280);
    P(4, 6, 0, 255);
    P(0, 6, 2, 255);
    P(7, 5, 3, 255);
    P(3, 5, 1, 255);
    qb = pb = 2;
    P(1, 0, 3, 16711680);
    P(3, 0, 2, 16711680);
    P(4, 5, 6, 16711680);
    P(6, 5, 7, 16711680);
    P(5, 4, 1, 65280);
    P(1, 4, 0, 65280);
    P(6, 7, 2, 65280);
    P(2, 7, 3, 65280);
    P(4, 6, 0, 255);
    P(0, 6, 2, 255);
    P(7, 5, 3, 255);
    P(3, 5, 1, 255);
    qb = pb = 0;
    for (c = k * m - 1; 0 <= c; c--)
        1 == Ub[c] && (z[c] = Vb(1, z[c], 0, 128))
}
function Rb(a, c, b, d, g, f, e, h, l, p, q) {
    var r = new E;
    Ab(r, c, g);
    g = new E;
    Ab(g, b, f);
    f = new E;
    Ab(f, d, e);
    e = new E;
    var s = new E;
    s.set(a);
    s.add(r);
    s.add(g);
    s.add(f);
    Ab(r, c, h);
    Ab(g, b, l);
    Ab(f, d, p);
    F = 0;
    J(e, s, r);
    e.add(g);
    e.sub(f);
    O(e);
    Ob(e, s, r);
    e.add(g);
    e.sub(f);
    O(e);
    Ob(e, s, r);
    e.add(g);
    e.add(f);
    O(e);
    J(e, s, r);
    e.add(g);
    e.add(f);
    O(e);
    J(e, s, r);
    e.sub(g);
    e.sub(f);
    O(e);
    Ob(e, s, r);
    e.sub(g);
    e.sub(f);
    O(e);
    Ob(e, s, r);
    e.sub(g);
    e.add(f);
    O(e);
    J(e, s, r);
    e.sub(g);
    e.add(f);
    O(e);
    Wb(0, 1, 2, 3, q);
    Wb(7, 6, 5, 4, q);
    Wb(1, 0, 4, 5, q);
    Wb(2, 1, 5, 6, q);
    Wb(3, 2, 6, 7, q);
    Wb(0, 3, 7, 4, q)
}
var Yb = new Xb;
function Xb() {
    this.count = this.value = this.n = this.a = this.index = this.max = 0
}
Xb.prototype.h = function() {
    this.max = 30;
    this.index = 0;
    this.a = Array(this.max);
    this.n = Array(this.max);
    this.value = Array(this.max);
    this.count = Array(this.max);
    for (var a = 0; a < this.max; a++)
        this.a[a] = new E,
        this.n[a] = new E,
        this.value[a] = 0,
        this.count[a] = 0
}
;
Xb.prototype.add = function(a, c, b) {
    c.y = 0;
    K(c);
    c.p(0.1);
    c.y = 0.2;
    this.a[this.index].set(a);
    Fb(this.a[this.index], this.a[this.index], 1);
    this.n[this.index].set(this.a[this.index]);
    this.a[this.index].add(c);
    this.value[this.index] = b;
    this.count[this.index] = 150;
    a = this.index + 1;
    c = this.max - 1;
    this.index = 0 > a ? c : a > c ? 0 : a
}
;
Xb.prototype.move = function() {
    for (var a = 0; a < this.max; a++)
        0 != this.value[a] && (Bb(this.a[a], this.n[a], -0.01, 0.98),
        Fb(this.a[a], this.n[a], 1),
        Zb(1, this.a[a].x - 0.5, this.a[a].z - 0.5, 5, 0.8 * this.count[a] / 150),
        this.count[a]--,
        0 == this.count[a] && (this.value[a] = 0))
}
;
Xb.prototype.k = function() {
    Q = 1;
    rb = 0;
    var a = [0, 16777215, 16711680, 16776960, 16744448, 65280, 65535, 255, 8388863, 16711935], c;
    for (c = 0; c < this.max; c++)
        if (0 != this.value[c]) {
            var b = y(255 * this.count[c] / 150);
            F = 0;
            O(this.a[c]);
            var d = y(0.8 * k * D[0].z)
              , g = y(1.6 * k * D[0].z);
            $b(Va.$, y(D[0].x - d / 2), y(D[0].y - g), D[0].z, d, g, 8 * this.value[c] + 128, 0, 8, 16, b << 24 | a[this.value[c]])
        }
    Q = 0;
    rb = 1
}
;
var N = new ac;
function ac() {
    this.la = this.log = this.m = this.c = this.f = this.a = this.type = this.b = this.max = this.g = this.e = 0
}
ac.prototype.h = function() {
    this.e = za[ea].e;
    this.g = za[ea].g;
    this.max = 500;
    this.b = 0;
    this.type = Array(this.max);
    this.a = Array(this.max);
    this.f = Array(this.max);
    this.c = Array(this.max);
    this.m = Array(this.max);
    this.log = Array(this.max);
    for (var a = this.la = 0; a < this.g; a++)
        for (var c = 0; c < this.e; c++) {
            var b = a * this.e + c
              , d = za[ea].K[b];
            if (0 != d)
                if (4278190335 == d) {
                    var b = I
                      , d = void 0
                      , g = new E;
                    A(g, c, 0, a);
                    for (d = 0; d < b.d.length; d++)
                        b.d[d].add(g);
                    for (d = 0; d < b.a.length; d++)
                        b.a[d].add(g);
                    for (d = 0; d < b.d.length; d++)
                        b.T[d].set(b.d[d]);
                    for (d = 0; d < b.a.length; d++)
                        b.n[d].set(b.a[d])
                } else
                    this.type[this.b] = d,
                    this.a[this.b] = new E,
                    A(this.a[this.b], c + 0, L.a[b].y, a + 0),
                    4278255360 == d ? (this.m[this.b] = 3,
                    this.f[this.b] = 1,
                    R(c, a, 2, 0.5)) : 4294967040 == d ? (this.m[this.b] = 3,
                    this.f[this.b] = 1,
                    R(c, a, 1.1, 0.5)) : 4286595072 == d ? (this.m[this.b] = 1,
                    this.f[this.b] = 1,
                    R(c, a, 1.1, 0.5)) : 4294902015 == d ? (this.m[this.b] = 2,
                    this.f[this.b] = 1,
                    R(c, a, 1.1, 0.1)) : 4286578943 == d ? (this.m[this.b] = 2,
                    this.f[this.b] = 1,
                    R(c, a, 1.1, 0.1)) : 4278222848 == d ? (this.m[this.b] = 1,
                    this.f[this.b] = 1,
                    R(c, a, 1.1, 0.1)) : 4286578688 == d ? (this.m[this.b] = 4,
                    this.f[this.b] = 3,
                    R(c, a, 3.1, 0.3),
                    R(c, a, 2, 1)) : 4294901760 == d ? (this.m[this.b] = 9,
                    this.f[this.b] = 3,
                    R(c, a, 4, 0.5),
                    R(c, a, 3, 0.5),
                    R(c, a, 2, 1)) : 4286611711 == d ? (this.m[this.b] = 8,
                    this.f[this.b] = 3,
                    R(c, a, 4.1, 0.3),
                    R(c, a, 1.1, 2)) : 4294934528 == d ? (this.m[this.b] = 4,
                    this.f[this.b] = 2,
                    R(c, a, 2.8, 0.5),
                    R(c, a, 2.1, 0.5)) : 4278190208 == d ? (this.m[this.b] = 7,
                    this.f[this.b] = 2,
                    R(c, a, 1.1, 1.1)) : 4286611456 == d ? (this.m[this.b] = 5,
                    this.f[this.b] = 1,
                    R(c, a, 2, 0.5)) : 4286611584 == d ? (this.m[this.b] = 6,
                    this.f[this.b] = 1,
                    R(c, a, 1.1, 1.1)) : 4282400832 == d ? (this.m[this.b] = 6,
                    this.f[this.b] = 1,
                    R(c, a, 1.1, 1.1)) : 4293787648 == d ? (this.m[this.b] = 9,
                    this.f[this.b] = 3,
                    R(c, a, 4, 0.5),
                    R(c, a, 3, 0.5),
                    R(c, a, 2, 1)) : 4293804032 == d ? (this.m[this.b] = 2,
                    this.f[this.b] = 2,
                    R(c, a, 1.1, 0.8)) : 4286643968 == d ? (this.m[this.b] = 5,
                    this.f[this.b] = 1,
                    R(c, a, 1.1, 0.8)) : 4290822144 == d ? (this.m[this.b] = 3,
                    this.f[this.b] = 1,
                    R(c, a, 1.1, 0.8)) : 4283786752 == d && (this.m[this.b] = 5,
                    this.f[this.b] = 1),
                    this.c[this.b] = !1,
                    this.b++
        }
}
;
ac.prototype.move = function() {
    var a = new E, c;
    for (c = 0; c < this.b; c++)
        this.c[c] || (J(a, this.a[c], I.l),
        Gb(a) > (I.F + this.f[c]) * (I.F + this.f[c]) || (a.y = 0,
        K(a),
        Pb(a, I.dir) < I.va || (this.c[c] = !0,
        Zb(0, this.a[c].x - 0.5, this.a[c].z - 0.5, 10 * this.f[c], this.f[c] * this.f[c] * 0.4),
        1 == this.f[c] ? C.create(0, bc, this.a[c], null) : 2 == this.f[c] ? C.create(0, cc, this.a[c], null) : 3 == this.f[c] && C.create(0, dc, this.a[c], null),
        Yb.add(this.a[c], a, this.m[c]),
        ia += this.m[c],
        this.log[this.la] = c,
        this.la++)))
}
;
ac.prototype.k = function(a) {
    H = pb = 1;
    var c = y(S(B.x - 16, 0, this.e - 1))
      , b = y(S(B.x + 17, 0, this.e - 1))
      , d = y(S(B.z - 19, 0, this.g - 1))
      , g = y(S(B.z + 10, 0, this.g - 1));
    0 == a && (c = 0,
    b = this.e - 1,
    d = 0,
    g = this.g - 1);
    var f = 1;
    0 == a && (f = 0);
    var e = new E;
    for (a = 0; a < this.b; a++)
        if (!(this.a[a].x < c || b < this.a[a].x || this.a[a].z < d || g < this.a[a].z))
            if (4278255360 == this.type[a])
                H = 0,
                T(this.a[a], 0.3, 1, 4, this.c[a] ? 8404992 : 2101248),
                H = 1,
                A(e, this.a[a].x, this.a[a].y + 1, this.a[a].z),
                ec(e, 1, 2, 6, this.c[a] ? 65280 : 16384);
            else if (4294967040 == this.type[a])
                H = 0,
                T(this.a[a], 0.1, 3, 4, this.c[a] ? 6684672 : 1638400),
                H = 1,
                A(e, this.a[a].x, this.a[a].y + 3, this.a[a].z),
                T(e, 0.4, 0.5, 6, this.c[a] ? 16776960 : 4210688);
            else if (4286595072 == this.type[a])
                H = f,
                T(this.a[a], 0.3, 1.8, 5, this.c[a] ? 10506240 : 2626560);
            else if (4294902015 == this.type[a]) {
                var h = 0.5;
                F = 0;
                A(e, this.a[a].x - h, this.a[a].y + 2 * h, this.a[a].z);
                M(e, 0, 0);
                A(e, this.a[a].x + h, this.a[a].y + 2 * h, this.a[a].z);
                M(e, 24, 0);
                A(e, this.a[a].x + h, this.a[a].y, this.a[a].z);
                M(e, 24, 24);
                A(e, this.a[a].x - h, this.a[a].y, this.a[a].z);
                M(e, 0, 24);
                Sb(Aa, this.c[a] ? 16777215 : 6316128)
            } else if (4286578943 == this.type[a])
                h = 0.5,
                F = 0,
                A(e, this.a[a].x - h, this.a[a].y + 2 * h, this.a[a].z),
                M(e, 0, 0),
                A(e, this.a[a].x + h, this.a[a].y + 2 * h, this.a[a].z),
                M(e, 24, 0),
                A(e, this.a[a].x + h, this.a[a].y, this.a[a].z),
                M(e, 24, 24),
                A(e, this.a[a].x - h, this.a[a].y, this.a[a].z),
                M(e, 0, 24),
                Sb(Ba, this.c[a] ? 16777215 : 6316128);
            else if (4278222848 == this.type[a]) {
                var l = 0.5
                  , p = 1.5 * l;
                F = 0;
                A(e, this.a[a].x - l, this.a[a].y + p, this.a[a].z - l);
                M(e, 0, 0);
                A(e, this.a[a].x + l, this.a[a].y + p, this.a[a].z + l);
                M(e, 32, 0);
                A(e, this.a[a].x + l, this.a[a].y, this.a[a].z + l);
                M(e, 32, 24);
                A(e, this.a[a].x - l, this.a[a].y, this.a[a].z - l);
                M(e, 0, 24);
                Sb(Da, this.c[a] ? 16777215 : 6316128);
                F = 0;
                A(e, this.a[a].x - l, this.a[a].y + p, this.a[a].z + l);
                M(e, 0, 0);
                A(e, this.a[a].x + l, this.a[a].y + p, this.a[a].z - l);
                M(e, 32, 0);
                A(e, this.a[a].x + l, this.a[a].y, this.a[a].z - l);
                M(e, 32, 24);
                A(e, this.a[a].x - l, this.a[a].y, this.a[a].z + l);
                M(e, 0, 24);
                Sb(Da, this.c[a] ? 16777215 : 6316128)
            } else if (4286578688 == this.type[a])
                H = f,
                T(this.a[a], 3, 0.5, 4, this.c[a] ? 12615680 : 3153920),
                T(this.a[a], 1.5, 1.5, 4, this.c[a] ? 8404992 : 2101248),
                H = 0,
                T(this.a[a], 0.2, 4, 6, 0),
                H = f,
                A(e, this.a[a].x, this.a[a].y + 4, this.a[a].z),
                ec(e, 2.2, 0.3, 4, this.c[a] ? 4227072 : 1056768);
            else if (4294901760 == this.type[a])
                H = f,
                T(this.a[a], 3, 1, 8, this.c[a] ? 8421504 : 2105376),
                T(this.a[a], 1.5, 2, 4, this.c[a] ? 12632256 : 3158064),
                H = 0,
                T(this.a[a], 0.5, 3, 8, this.c[a] ? 16777215 : 4210752),
                A(e, this.a[a].x, this.a[a].y + 3, this.a[a].z),
                ec(e, 0.5, 2, 8, this.c[a] ? 16711680 : 4194304),
                A(e, this.a[a].x - 2.1, this.a[a].y, this.a[a].z - 2.1),
                T(e, 0.4, 2, 8, this.c[a] ? 12632256 : 3158064),
                e.y = 2,
                ec(e, 0.4, 1, 8, this.c[a] ? 255 : 64),
                A(e, this.a[a].x + 2.1, this.a[a].y, this.a[a].z - 2.1),
                T(e, 0.4, 2, 8, this.c[a] ? 12632256 : 3158064),
                e.y = 2,
                ec(e, 0.4, 0.9, 8, this.c[a] ? 16711935 : 4194368),
                A(e, this.a[a].x + 2.1, this.a[a].y, this.a[a].z + 2.1),
                T(e, 0.4, 2, 8, this.c[a] ? 12632256 : 3158064),
                e.y = 2,
                ec(e, 0.4, 0.7, 8, this.c[a] ? 65280 : 16384),
                A(e, this.a[a].x - 2.1, this.a[a].y, this.a[a].z + 2.1),
                T(e, 0.4, 2, 8, this.c[a] ? 12632256 : 3158064),
                e.y = 2,
                ec(e, 0.4, 0.8, 8, this.c[a] ? 16776960 : 4210688);
            else if (4286611711 == this.type[a])
                H = f,
                T(this.a[a], 3, 0.5, 16, this.c[a] ? 255 : 64),
                T(this.a[a], 1, 2, 8, this.c[a] ? 10539263 : 2634816),
                H = 0,
                A(e, this.a[a].x, this.a[a].y + 2, this.a[a].z),
                ec(e, 0.2, 1, 8, this.c[a] ? 255 : 64);
            else if (4294934528 == this.type[a])
                H = f,
                T(this.a[a], 2, 1, 4, this.c[a] ? 4198400 : 1049600),
                h = 2,
                p = 1.05,
                F = 0,
                A(e, this.a[a].x - h, this.a[a].y + p, this.a[a].z),
                M(e, 0, 0),
                A(e, this.a[a].x, this.a[a].y + p, this.a[a].z - h),
                M(e, 64, 0),
                A(e, this.a[a].x + h, this.a[a].y + p, this.a[a].z),
                M(e, 64, 64),
                A(e, this.a[a].x, this.a[a].y + p, this.a[a].z + h),
                M(e, 0, 64),
                Sb(Ca, this.c[a] ? 16777215 : 4210752);
            else if (4278190208 == this.type[a]) {
                H = f;
                T(this.a[a], 0.5, 3, 8, this.c[a] ? 8404992 : 2101248);
                var q = new E;
                A(q, 1, 0, 0);
                var r = new E;
                A(r, 0, 1, 0);
                var s = new E;
                A(s, 0, 0, 1);
                Rb(this.a[a], q, r, s, 0, 2, 0.3, 2, 0.5, 0.3, this.c[a] ? 15782016 : 3945504);
                var l = 2
                  , p = 0.5
                  , v = 0.61;
                F = 0;
                A(e, this.a[a].x - l, this.a[a].y + p + 2, this.a[a].z + v);
                M(e, 0, 0);
                A(e, this.a[a].x + l, this.a[a].y + p + 2, this.a[a].z + v);
                M(e, 128, 0);
                A(e, this.a[a].x + l, this.a[a].y - p + 2, this.a[a].z + v);
                M(e, 128, 32);
                A(e, this.a[a].x - l, this.a[a].y - p + 2, this.a[a].z + v);
                M(e, 0, 32);
                Sb(ua, this.c[a] ? 16777215 : 4210752)
            } else
                4286611456 == this.type[a] ? (H = f,
                A(e, this.a[a].x, this.a[a].y, this.a[a].z),
                T(e, 0.8, 0.8, 5, this.c[a] ? 8409088 : 2102272)) : 4286611584 == this.type[a] ? (H = f,
                T(this.a[a], 0.6, 0.5, 8, this.c[a] ? 8421504 : 2105376),
                H = 0,
                A(e, this.a[a].x, this.a[a].y + 0.5, this.a[a].z),
                ec(e, 0.4, 3.5, 8, this.c[a] ? 12632256 : 3158064),
                H = 0,
                h = 0.5,
                l = 1 * h,
                p = 0.75 * h,
                v = 0.6 * h,
                q = new E,
                A(q, 1, 0, 0),
                r = new E,
                A(r, 0, 1, 0),
                s = new E,
                A(s, 0, 0, 1),
                Rb(this.a[a], q, r, s, 0, 4, 0, l, p, v, this.c[a] ? 16777215 : 4210752),
                Rb(this.a[a], q, r, s, 0.5 * h, 4 + 0.8 * h, 0, 0.1, 0.1, 0.1, this.c[a] ? 2105376 : 526344),
                Rb(this.a[a], q, r, s, -0.5 * h, 4 + 0.8 * h, 0, 0.1, 0.1, 0.1, this.c[a] ? 2105376 : 526344),
                F = 0,
                A(e, this.a[a].x - l, this.a[a].y + p + 4, this.a[a].z + v),
                M(e, 0, 0),
                A(e, this.a[a].x + l, this.a[a].y + p + 4, this.a[a].z + v),
                M(e, 32, 0),
                A(e, this.a[a].x + l, this.a[a].y - p + 4, this.a[a].z + v),
                M(e, 32, 24),
                A(e, this.a[a].x - l, this.a[a].y - p + 4, this.a[a].z + v),
                M(e, 0, 24),
                Sb(sa, this.c[a] ? 16777215 : 4210752)) : 4282400832 == this.type[a] ? (H = 0,
                T(this.a[a], 0.3, 1.5, 8, this.c[a] ? 12632256 : 3158064),
                T(this.a[a], 0.2, 4, 8, this.c[a] ? 12632256 : 3158064),
                h = 0.5,
                l = 1 * h,
                p = 0.75 * h,
                v = 0.6 * h,
                q = new E,
                A(q, 1, 0, 0),
                r = new E,
                A(r, 0, 1, 0),
                s = new E,
                A(s, 0, 0, 1),
                Rb(this.a[a], q, r, s, 0, 4, 0, l, p, v, this.c[a] ? 16777215 : 4210752),
                Rb(this.a[a], q, r, s, 0.5 * h, 4 + 0.8 * h, 0, 0.1, 0.1, 0.1, this.c[a] ? 2105376 : 526344),
                Rb(this.a[a], q, r, s, -0.5 * h, 4 + 0.8 * h, 0, 0.1, 0.1, 0.1, this.c[a] ? 2105376 : 526344),
                F = 0,
                A(e, this.a[a].x - p, this.a[a].y + p + 4, this.a[a].z + v),
                M(e, 0, 0),
                A(e, this.a[a].x + p, this.a[a].y + p + 4, this.a[a].z + v),
                M(e, 32, 0),
                A(e, this.a[a].x + p, this.a[a].y - p + 4, this.a[a].z + v),
                M(e, 32, 32),
                A(e, this.a[a].x - p, this.a[a].y - p + 4, this.a[a].z + v),
                M(e, 0, 32),
                Sb(Fa, this.c[a] ? 16777215 : 4210752)) : 4293787648 == this.type[a] ? (H = 0,
                e.set(this.a[a]),
                e.y = 0,
                T(e, 3, 1, 4, this.c[a] ? 16760896 : 4206608),
                e.y = 1,
                T(e, 2, 1, 4, this.c[a] ? 16765040 : 4207644),
                e.y = 2,
                T(e, 1, 1, 4, this.c[a] ? 16769184 : 4208680),
                e.y = 3,
                ec(e, 0.5, 1, 4, this.c[a] ? 16773328 : 4209716)) : 4293804032 == this.type[a] ? (H = 0,
                ec(this.a[a], 1.5, 1.5, 4, this.c[a] ? 16776960 : 4210688)) : 4286643968 == this.type[a] ? (H = f,
                T(this.a[a], 0.3, 2, 8, this.c[a] ? 65280 : 16384),
                A(e, this.a[a].x - 0.6, this.a[a].y + 1, this.a[a].z),
                T(e, 0.26, 1.2, 8, this.c[a] ? 65280 : 16384),
                A(e, this.a[a].x + 0.6, this.a[a].y + 1.25, this.a[a].z),
                T(e, 0.26, 1.2, 8, this.c[a] ? 65280 : 16384)) : 4290822144 == this.type[a] ? (H = f,
                ec(this.a[a], 0.3, 2.6, 4, this.c[a] ? 12290082 : 3023368),
                A(e, this.a[a].x, this.a[a].y + 2.5, this.a[a].z),
                F = 0,
                O(e),
                l = y(3 * k * D[0].z),
                p = y(3 * k * D[0].z),
                $b(wa, y(D[0].x - y(l / 2)), y(D[0].y - y(p / 2)), D[0].z, l, p, 0, 0, 64, 64, this.c[a] ? 16777215 : 4210752)) : 4283786752 == this.type[a] && (h = 0.5,
                l = 0.1,
                F = 0,
                A(e, this.a[a].x - h, this.a[a].y + l, this.a[a].z - h),
                M(e, 0, 0),
                A(e, this.a[a].x + h, this.a[a].y + l, this.a[a].z - h),
                M(e, 32, 0),
                A(e, this.a[a].x + h, this.a[a].y + l, this.a[a].z + h),
                M(e, 32, 32),
                A(e, this.a[a].x - h, this.a[a].y + l, this.a[a].z + h),
                M(e, 0, 32),
                Q = 1,
                Sb(Ea, 1610612736),
                Q = 0,
                l = h = 0.5,
                F = 0,
                A(e, this.a[a].x - h, this.a[a].y + l, this.a[a].z - h),
                M(e, 0, 0),
                A(e, this.a[a].x + h, this.a[a].y + l, this.a[a].z - h),
                M(e, 32, 0),
                A(e, this.a[a].x + h, this.a[a].y + l, this.a[a].z + h),
                M(e, 32, 32),
                A(e, this.a[a].x - h, this.a[a].y + l, this.a[a].z + h),
                M(e, 0, 32),
                Sb(Ea, this.c[a] ? 16777215 : 6316128));
    H = pb = 0
}
;
function ec(a, c, b, d, g) {
    var f, e = new E;
    for (f = F = 0; f < d; f++)
        e.x = a.x + u[y(512 * f / d)][0] * c,
        e.y = a.y,
        e.z = a.z + u[y(512 * f / d)][1] * c,
        O(e);
    e.x = a.x;
    e.y = a.y + b;
    e.z = a.z;
    O(e);
    for (f = 0; f < d - 1; f++)
        P(f, f + 1, d, g);
    P(f, 0, d, g)
}
function T(a, c, b, d, g) {
    var f, e = new E;
    for (f = F = 0; f < d; f++)
        e.x = a.x + u[y(512 * f / d)][0] * c,
        e.y = a.y,
        e.z = a.z + u[y(512 * f / d)][1] * c,
        O(e);
    for (f = 0; f < d; f++)
        e.x = a.x + u[y(512 * f / d)][0] * c,
        e.y = a.y + b,
        e.z = a.z + u[y(512 * f / d)][1] * c,
        O(e);
    e.x = a.x;
    e.y = a.y + b;
    e.z = a.z;
    O(e);
    for (f = 0; f < d - 1; f++)
        Wb(f, f + 1, f + d + 1, f + d, g);
    Wb(f, 0, d, f + d, g);
    for (f = 0; f < d - 1; f++)
        P(f + d, f + d + 1, d + d, g);
    P(f + d, d, d + d, g)
}
var L = new fc;
function fc() {
    this.r = this.ga = this.ca = this.s = this.fa = this.o = this.N = this.a = this.g = this.e = 0
}
fc.prototype.h = function() {
    this.e = ya[ea].e;
    this.g = ya[ea].g;
    var a = this.e * this.g;
    this.a = Array(a);
    this.N = Array(a);
    this.o = Array(a);
    this.fa = Array(a);
    this.s = Array(a);
    this.ca = Array(a);
    this.ga = Array(a);
    this.r = [Array(a), Array(a)];
    for (a = 0; a < this.g; a++)
        for (var c = 0; c < this.e; c++) {
            var b = a * this.e + c;
            this.a[b] = new E;
            A(this.a[b], c, 0, a);
            this.N[b] = ya[ea].K[b];
            this.o[b] = 0;
            this.s[b] = new E;
            this.ca[b] = new E;
            this.ga[b] = new E;
            this.r[0][b] = 0.2;
            this.r[1][b] = 0
        }
    for (a = 0; a < this.g - 1; a++)
        for (c = 0; c < this.e - 1; c++) {
            var b = a * this.e + c
              , d = 0;
            if (4278190335 == this.N[b])
                d = -0.5;
            else if (4278190310 == this.N[b])
                d = -0.5;
            else
                continue;
            this.a[b].y = d;
            this.o[b] = d;
            this.a[b + 1].y = d;
            this.o[b + 1] = d;
            this.a[b + this.e].y = d;
            this.o[b + this.e] = d;
            this.a[b + this.e + 1].y = d;
            this.o[b + this.e + 1] = d
        }
}
;
fc.prototype.k = function(a) {
    var c, b, d;
    H = 1;
    c = y(S(B.x - 16, 0, this.e - 1));
    var g = y(S(B.x + 17, 0, this.e - 1))
      , f = y(S(B.z - 19, 0, this.g - 1))
      , e = y(S(B.z + 7, 0, this.g - 1));
    0 == a && (c = 0,
    g = this.e - 1,
    f = 0,
    e = this.g - 1,
    H = 0);
    var h = g - c + 1;
    F = 0;
    d = f * this.e + c;
    for (b = f; b <= e; b++) {
        for (a = c; a <= g; a++,
        d++)
            O(this.a[d]);
        d += this.e - h
    }
    var l = 0;
    d = f * this.e + c;
    for (b = f; b < e; b++) {
        for (a = c; a < g; a++,
        d++)
            f = 1 > this.r[0][d] + this.r[1][d] ? this.r[0][d] + this.r[1][d] : 1,
            Wb(l, l + 1, l + h + 1, l + h, y((this.N[d] >> 16 & 255) * f) << 16 | y((this.N[d] >> 8 & 255) * f) << 8 | y((this.N[d] & 255) * f)),
            l++;
        l++;
        d += this.e - h + 1
    }
    H = 0;
    for (c = this.e * this.g - 1; 0 <= c; c--)
        this.r[1][c] = 0
}
;
function Zb(a, c, b, d, g) {
    for (var f = L, e = y(0 < c - d ? c - d : 0), h = y(c + d < f.e - 1 ? c + d : f.e - 1), l = y(b + d < f.g - 1 ? b + d : f.g - 1), p = y(0 < b - d ? b - d : 0); p < l; p++)
        for (var q = e; q < h; q++) {
            var r = q - c
              , s = p - b
              , r = Math.sqrt(r * r + s * s);
            r < d && (1.2 > r && (r = 1.2),
            s = p * f.e + q,
            f.r[a][s] += g / r / r,
            f.r[a][s] = 1 > f.r[a][s] ? f.r[a][s] : 1)
        }
}
function R(a, c, b, d) {
    var g = L
      , f = y(0 < a - b ? a - b : 0)
      , e = y(a + b < g.e - 1 ? a + b : g.e - 1)
      , h = y(c + b < g.g - 1 ? c + b : g.g - 1)
      , l = b * b;
    for (b = y(0 < c - b ? c - b : 0); b <= h; b++)
        for (var p = f; p <= e; p++) {
            var q = p - a
              , r = b - c;
            q * q + r * r < l && (g.o[b * g.e + p] += d)
        }
}
function Fb(a, c, b) {
    var d = L
      , g = new E;
    J(g, a, c);
    var f = y(g.O() / 0.1 + 1);
    Nb(g, f);
    var e = new E;
    e.set(c);
    c = new E;
    var h, l = 0, p = new E;
    A(p, 1, 0, -1);
    var q = new E;
    A(q, -1, 0, -1);
    for (var r = new E, s = 0; s < f; s++) {
        c.set(e);
        e.add(g);
        h = 0;
        0.1 > e.x && (e.x = 0.1);
        e.x > d.e - 1.1 && (e.x = d.e - 1.1);
        0.1 > e.z && (e.z = 0.1);
        e.z > d.g - 1.1 && (e.z = d.g - 1.1);
        var v = y(e.z) * d.e + y(e.x);
        J(r, e, d.s[v]);
        h = 1 >= d.fa[v] ? 0 < Pb(p, r) ? h + gc(e, d.s[v], d.ca[v]) : h + gc(e, d.s[v], d.ga[v]) : 0 < Pb(q, r) ? h + gc(e, d.s[v], d.ca[v]) : h + gc(e, d.s[v], d.ga[v]);
        0 != h && (J(g, e, c),
        g.p(b),
        l = 1)
    }
    a.set(e);
    return l
}
function gc(a, c, b) {
    var d = new E;
    J(d, a, c);
    c = Pb(b, d);
    if (0.1 <= c)
        return 0;
    Ab(d, b, 0.1 - c);
    a.add(d);
    return 1
}
function Jb(a) {
    var c = L
      , b = y(a.z) * c.e + y(a.x);
    a = c.N[b] >> 16 & 255;
    var d = c.N[b] >> 8 & 255
      , c = c.N[b] & 255;
    if (a != d || d != c) {
        if (a >= d && a >= c)
            return 1;
        if (d >= a && d >= c)
            return 2;
        if (c >= a && c >= d)
            return 3
    }
    return 0
}
var bc = 1
  , cc = 2
  , dc = 3
  , Db = 4
  , Eb = 5
  , Ib = 6
  , Kb = 7
  , Lb = 8
  , Mb = 9
  , hc = 10
  , ic = 11
  , jc = 12
  , kc = 13
  , db = Array(14);
function eb(a, c, b, d, g, f, e, h, l, p, q, r, s, v, U, Z, X, ja, oa, fb, ka, Na, gb, hb, ib, yc, zc, yd, zd, Ad, Bd, Cd, Dd, Ed, Fd, Gd, Hd, Id, Jd, Kd, Ld, Md, Nd, Od, Pd, Qd, Rd, Sd, Td, Ud) {
    this.b = a;
    this.Z = this.Ea = this.ma = 0;
    this.Ya = c;
    this.q = b;
    this.Fa = d;
    this.Ga = g;
    this.Va = f;
    this.Ua = e;
    this.ea = new E;
    A(this.ea, h, l, 0);
    this.n = new E;
    A(this.n, p, q, 0);
    this.aa = new E;
    A(this.aa, r, s, 0);
    this.ba = new E;
    A(this.ba, v, U, 0);
    this.bb = Z;
    this.ab = X;
    this.za = new E;
    A(this.za, ja, oa, 0);
    this.Aa = new E;
    A(this.Aa, fb, ka, 0);
    this.Ba = new E;
    A(this.Ba, Na, gb, 0);
    this.Ca = new E;
    A(this.Ca, hb, ib, 0);
    this.cb = yc;
    this.Xa = zc;
    this.Oa = yd;
    this.Ja = zd;
    this.$a = Ad;
    this.hb = Bd;
    this.ya = Cd;
    this.Ka = Dd;
    this.eb = Ed;
    this.Wa = Fd;
    this.Za = Gd;
    this.Da = Hd;
    this.Ta = Id;
    this.sa = Jd;
    this.ra = Kd;
    this.qa = Ld;
    this.ka = Md;
    this.Sa = Nd;
    this.Ra = Od;
    this.Qa = Pd;
    this.Pa = Qd;
    this.Ma = Rd;
    this.Na = Sd;
    this.fb = Td;
    this.gb = Ud
}
function lc() {
    this.a = new E;
    this.j = new E;
    this.scale = new E;
    this.G = new E;
    this.f = this.U = this.S = this.D = this.X = this.W = this.R = this.Q = this.q = this.i = this.na = this.P = 0
}
function mc() {
    this.da = new E;
    this.ua = new E;
    this.xa = this.b = this.wa = this.ma = this.Z = this.id = this.La = 0;
    this.C = Array(8);
    for (var a = 0; 8 > a; a++)
        this.C[a] = new lc
}
var C = new nc
  , oc = Array(128)
  , pc = Array(128)
  , qc = 0
  , rc = 0;
function nc() {}
nc.prototype.h = function() {
    for (var a = 0; 128 > a; a++)
        oc[a] = new mc,
        pc[a] = 0,
        oc[a].wa = a;
    rc = qc = 0
}
;
nc.prototype.reset = function() {
    for (var a = 0; 128 > a; a++)
        pc[a] = 0,
        oc[a].wa = a;
    rc = qc = 0
}
;
nc.prototype.move = function() {
    var a, c = qc;
    for (a = 0; 128 > a; a++)
        if (c = c + 1 & 127,
        1 == pc[c]) {
            for (var b = oc[c], d = db[b.id], g = new E, f = 0; f < b.b; f++) {
                var e = b.C[f];
                e.i++;
                if (0 >= e.i)
                    0 == e.i && sc(b, f, d);
                else {
                    if (e.i > e.q) {
                        if (0 == b.Z)
                            continue;
                        sc(b, f, d);
                        e.i = 1
                    }
                    if (0 == d.Ea)
                        e.a.add(e.j),
                        e.j.p(d.Oa),
                        e.j.y += d.Xa;
                    else if (1 == d.Ea) {
                        J(g, e.a, b.da);
                        var h = new E;
                        h.set(g);
                        K(h);
                        h.p(e.j.y);
                        g.add(h);
                        var h = Math.sin(e.j.x)
                          , l = Math.cos(e.j.x)
                          , p = l * g.x + h * g.z;
                        g.z = -h * g.x + l * g.z;
                        g.x = p;
                        Ob(e.a, g, b.da);
                        e.j.p(d.Oa)
                    }
                    1 == d.ya && (e.P += e.na);
                    1 == d.Ka ? e.scale.add(e.G) : 2 == d.Ka && (e.scale.add(e.G),
                    e.G.p(d.cb));
                    0 == d.Da ? e.D = d.ka : 1 == d.Da && (h = e.i / e.q,
                    e.f = y(d.sa + (d.Sa - d.sa) * h),
                    e.U = y(d.ra + (d.Ra - d.ra) * h),
                    e.S = y(d.qa + (d.Qa - d.qa) * h),
                    e.D = y(d.ka + (d.Pa - d.ka) * h));
                    e.i < d.Fa && (e.D = y(e.D * e.i / d.Fa));
                    e.q - e.i < d.Ga && (e.D = y(e.D * (e.q - e.i) / d.Ga))
                }
            }
            if (0 <= b.Z)
                if (0 < b.Z)
                    b.Z--;
                else {
                    d = 1;
                    for (f = 0; f < b.b; f++)
                        if (e = b.C[f],
                        e.i <= e.q) {
                            d = 0;
                            break
                        }
                    0 != d && 0 != rc && (b.La = 0,
                    pc[b.wa] = 0,
                    rc--)
                }
        }
}
;
nc.prototype.k = function(a) {
    var c, b = qc;
    for (c = 0; 128 > c; c++)
        if (b = b + 1 & 127,
        1 == pc[b] && oc[b].ma == a) {
            var d = oc[b]
              , g = db[d.id]
              , f = void 0
              , e = void 0
              , h = void 0;
            Q = g.Ta;
            rb = 0;
            switch (g.Wa) {
            case 1:
                for (e = 0; e < d.b; e++)
                    if (f = d.C[e],
                    !(0 >= f.i || f.q < f.i)) {
                        h = f.D << 24 | f.f << 16 | f.U << 8 | f.S;
                        F = 0;
                        O(f.a);
                        var f = y(D[0].x)
                          , l = y(D[0].y);
                        0 > f || k <= f || 0 > l || m <= l || (f = l * k + f,
                        tc[f] > D[0].z || (z[f] = 0 == Q ? h : Vb(Q, z[f], h, h >> 24 & 255)))
                    }
                break;
            case 2:
                l = new E;
                for (e = 0; e < d.b; e++)
                    f = d.C[e],
                    0 >= f.i || f.q < f.i || (l.set(f.j),
                    K(l),
                    l.p(f.scale.x),
                    l.add(f.a),
                    h = f.D << 24 | f.f << 16 | f.U << 8 | f.S,
                    F = 0,
                    O(f.a),
                    O(l),
                    uc(D[0].x, D[0].y, D[1].x, D[1].y, h));
                break;
            case 3:
                for (var l = new E, g = new E, p = new E, e = 0; e < d.b; e++)
                    f = d.C[e],
                    0 >= f.i || f.q < f.i || (g.x = Math.cos(f.P) * f.scale.x,
                    g.y = Math.sin(f.P) * f.scale.y,
                    p.x = -g.y,
                    p.y = g.x,
                    Ob(l, g, p),
                    l.p(0.70711));
                break;
            case 4:
                for (e = 0; e < d.b; e++)
                    f = d.C[e],
                    0 >= f.i || f.q < f.i || (h = f.D << 24 | f.f << 16 | f.U << 8 | f.S,
                    F = 0,
                    O(f.a),
                    l = y(f.scale.x * k * D[0].z),
                    g = y(f.scale.y * k * D[0].z),
                    $b(Ga, y(D[0].x - l / 2), y(D[0].y - g / 2), D[0].z, l, g, y(f.Q), y(f.R), y(f.W - f.Q), y(f.X - f.R), h));
                break;
            case 5:
                for (var g = new E, p = new E, q = new E, r = new E, e = 0; e < d.b; e++)
                    f = d.C[e],
                    0 >= f.i || f.q < f.i || (p.set(f.j),
                    J(g, bb, B),
                    Qb(g, p, g),
                    K(g),
                    K(p),
                    g.p(f.scale.x),
                    p.p(f.scale.y),
                    J(q, p, g),
                    Ob(r, p, g),
                    h = f.D << 24 | f.f << 16 | f.U << 8 | f.S,
                    F = 0,
                    Ob(g, f.a, q),
                    M(g, y(f.Q), y(f.R)),
                    Ob(g, f.a, r),
                    M(g, y(f.W), y(f.R)),
                    J(g, f.a, q),
                    M(g, y(f.W), y(f.X)),
                    J(g, f.a, r),
                    M(g, y(f.Q), y(f.X)),
                    Sb(Ga, h));
                break;
            case 6:
                if (l = new E,
                0 == g.ya)
                    for (e = 0; e < d.b; e++)
                        f = d.C[e],
                        0 >= f.i || f.q < f.i || (h = f.D << 24 | f.f << 16 | f.U << 8 | f.S,
                        F = 0,
                        l.set(f.a),
                        l.x += f.scale.x,
                        M(l, y(f.Q), y(f.R)),
                        l.set(f.a),
                        l.z += f.scale.y,
                        M(l, y(f.W), y(f.R)),
                        l.set(f.a),
                        l.x -= f.scale.x,
                        M(l, y(f.W), y(f.X)),
                        l.set(f.a),
                        l.z -= f.scale.x,
                        M(l, y(f.Q), y(f.X)),
                        Sb(Ga, h));
                else
                    for (q = new E,
                    r = new E,
                    e = 0; e < d.b; e++)
                        f = d.C[e],
                        0 >= f.i || f.q < f.i || (q.x = u[y(512 * f.P) & 511][0] * f.scale.x,
                        q.y = 0,
                        q.z = u[y(512 * f.P) & 511][1] * f.scale.y,
                        r.x = -q.z,
                        r.y = 0,
                        r.z = q.x,
                        h = f.D << 24 | f.f << 16 | f.U << 8 | f.S,
                        F = 0,
                        Ob(l, f.a, q),
                        M(l, y(f.Q), y(f.R)),
                        Ob(l, f.a, r),
                        M(l, y(f.W), y(f.R)),
                        J(l, f.a, q),
                        M(l, y(f.W), y(f.X)),
                        J(l, f.a, r),
                        M(l, y(f.Q), y(f.X)),
                        Sb(Ga, h))
            }
            Q = 0;
            rb = 1
        }
}
;
nc.prototype.create = function(a, c, b, d) {
    var g, f = db[c], e;
    a: {
        for (g = 0; 128 > g; g++)
            if (qc = qc + 1 & 127,
            0 == pc[qc]) {
                pc[qc] = 1;
                rc++;
                e = qc;
                break a
            }
        e = -1
    }
    if (-1 != e)
        for (g = oc[e],
        null != b ? g.da.set(b) : A(g.da, 0, 0, 0),
        null != d ? g.ua.set(d) : A(g.ua, 0, 0, 0),
        g.La = a,
        g.id = c,
        g.Z = f.Z,
        g.ma = f.ma,
        g.b = f.b,
        g.xa = Hb(1),
        a = g.b,
        e = 0; e < a; e++)
            g.C[e].i = -vc(f.Va, f.Ua),
            g.C[e].q = 0,
            0 <= g.C[e].i && sc(g, e, f)
}
;
function sc(a, c, b) {
    var d = a.C[c];
    switch (b.$a) {
    default:
        A(d.a, 0, 0, 0);
        break;
    case 1:
        d.a.x = V(b.ea.x, b.n.x);
        d.a.y = V(b.ea.y, b.n.y);
        d.a.z = V(b.ea.x, b.n.x);
        break;
    case 2:
        var g = y(512 * a.xa) + y(512 * c / a.b) & 511
          , f = V(b.ea.x, b.n.x);
        d.a.x = u[g][0] * f;
        d.a.y = V(b.ea.y, b.n.y);
        d.a.z = u[g][1] * f
    }
    switch (b.hb) {
    default:
        A(d.j, 0, 0, 0);
        break;
    case 1:
        d.j.x = V(b.aa.x, b.ba.x);
        d.j.y = V(b.aa.y, b.ba.y);
        d.j.z = V(b.aa.x, b.ba.x);
        break;
    case 2:
        g = y(512 * a.xa) + y(512 * c / a.b) & 511;
        f = V(b.aa.x, b.ba.x);
        d.j.x = u[g][0] * f;
        d.j.y = V(b.aa.y, b.ba.y);
        d.j.z = u[g][1] * f;
        break;
    case 3:
        c = new E,
        c.set(d.a),
        K(c),
        Ab(d.j, c, V(b.aa.x, b.ba.x))
    }
    switch (b.Za) {
    case 1:
        d.a.add(a.da);
        break;
    case 2:
        d.a.add(B);
        break;
    case 3:
        c = new E;
        g = new E;
        f = new E;
        f.set(a.ua);
        var e = new E;
        Qb(g, f, cb);
        Qb(e, g, f);
        K(g);
        K(f);
        K(e);
        c.x = g.x * d.a.x + f.x * d.a.y + e.x * d.a.z;
        c.y = g.y * d.a.x + f.y * d.a.y + e.y * d.a.z;
        c.z = g.z * d.a.x + f.z * d.a.y + e.z * d.a.z;
        d.a.set(c);
        c.x = g.x * d.j.x + f.x * d.j.y + e.x * d.j.z;
        c.y = g.y * d.j.x + f.y * d.j.y + e.y * d.j.z;
        c.z = g.z * d.j.x + f.z * d.j.y + e.z * d.j.z;
        d.j.set(c);
        d.a.add(a.da)
    }
    d.scale.x = V(b.za.x, b.Aa.x);
    d.scale.y = V(b.za.y, b.Aa.y);
    d.G.x = V(b.Ba.x, b.Ca.x);
    d.G.y = V(b.Ba.y, b.Ca.y);
    d.G.x -= d.scale.x;
    d.G.y -= d.scale.y;
    1 == b.eb && (d.scale.y = d.scale.x,
    d.G.y = d.G.x);
    switch (b.ya) {
    default:
        d.P = 0;
        d.na = 0;
        break;
    case 1:
        d.P = V(0, 1);
        d.na = V(b.bb, b.ab);
        break;
    case 2:
        d.P = V(0, 1),
        d.na = 0
    }
    d.i = 0;
    d.q = y(V(b.Ya, b.q));
    d.Q = b.Ma;
    d.R = b.Na;
    d.W = b.Ma + b.fb;
    d.X = b.Na + b.gb;
    d.D = b.ka;
    d.S = b.qa;
    d.U = b.ra;
    d.f = b.sa;
    0 == b.Ja ? Nb(d.G, d.q) : Nb(d.G, b.Ja)
}
var wc = document
  , xc = window
  , La = wc.getElementById("cv")
  , Ac = La.getContext("2d")
  , Bc = Ac.createImageData(k, m)
  , Ua = new Uint8Array(Bc.data.buffer)
  , Cc = xc.console
  , W = String.fromCharCode
  , $a = setTimeout
  , Dc = 'dan-ball.jp';
xc.fff = Ec;
function Ec(a, c, b) {
    try {
        La = wc.getElementById("cv"),
        Ac = La.getContext("2d"),
        Ac.putImageData(a, c, b)
    } catch (d) {}
}
xc.fff = Ja;
function Ja(a) {
    try {
        Cc.log(a)
    } catch (c) {}
}
xc.Init = Ia;
var Ka = W(67, 111, 112, 121, 114, 105, 103, 104, 116, 40, 67, 41, 32, 50, 48, 48, 55, 32, 104, 97, 53, 53, 105, 105)
  , Fc = W(46, 47, 100, 97, 116, 97, 47)
  , Gc = W(102, 112, 115)
  , Hc = W(99, 97, 110, 118, 97, 115)
  , Ic = W(50, 100)
  , Jc = 0
  , Kc = W(100, 97, 110, 45, 98, 97, 108, 108, 46, 106, 112)
  , z = new Int32Array(k * m)
  , tc = new Float32Array(k * m)
  , Ub = new Int32Array(k * m)
  , Y = new Int32Array(m)
  , Lc = new Int32Array(m)
  , Mc = new Float32Array(m)
  , Nc = new Float32Array(m)
  , Oc = new Float32Array(m)
  , Pc = new Float32Array(m)
  , Qc = new Float32Array(m)
  , Rc = new Float32Array(m);
function mb() {
    Sc = !1 == zb && !0 == Tc;
    Uc = !0 == zb && !1 == Tc;
    zb = Tc;
    Vc = Wc;
    Xc = Yc;
    for (var a = 0; 256 > a; a++)
        Oa[a] = Pa[a],
        Pa[a] = !1;
    Sa = Sa + y(1024 * Math.random()) & 1023;
    Ta = y(512 * Math.random()) | 1;
    if (0 < Zc)
        Zc++;
    else
        switch ($c(285212672),
        ad(),
        ob.p(jb),
        n) {
        case 0:
            $c(16777215);
            I.h();
            da = t = 0;
            n++;
            break;
        case 1:
        case 2:
            a = new E;
            A(a, B.x, 0, B.z);
            pb = 2;
            ec(a, 2.6, 5, 8, 11184776);
            pb = 0;
            T(a, 2.6, 0, 8, 15658683);
            Sc && (sb = vc(1, 4.9),
            tb = 10);
            0 != tb && (tb--,
            I.d[sb].y += 0.1);
            var a = I, c, b = new E;
            c = yb();
            null != c && (a.dir.y = 0,
            K(a.dir),
            c.y = a.d[1].y,
            J(b, c, a.d[1]),
            K(b),
            b.add(a.dir),
            K(b),
            Ab(b, b, 0.01),
            a.d[1].add(b),
            c.y = a.d[2].y,
            J(b, c, a.d[2]),
            K(b),
            b.add(a.dir),
            K(b),
            Ab(b, b, 0.01),
            a.d[2].add(b));
            Bb(a.d[0], a.T[0], 0.01, 0.99);
            for (c = 1; c < a.d.length; c++)
                Bb(a.d[c], a.T[c], -0.01, 0.99);
            for (c = 0; c < a.a.length; c++)
                Bb(a.a[c], a.n[c], -0.01, 0.99);
            for (c = 0; c < a.H.length; c++)
                Cb(a.d[a.H[c].ha], a.d[a.H[c].ia], a.H[c].O, 0.5);
            for (c = 0; c < a.J.length; c++)
                Cb(a.a[a.J[c].ha], a.d[a.J[c].ia], a.J[c].O, 0.1);
            for (c = 0; c < a.a.length; c++)
                A(b, a.a[c].x, 0, a.a[c].z),
                25 < Gb(b) && (K(b),
                b.p(5),
                a.a[c].x = b.x,
                a.a[c].z = b.z),
                a.a[c].y = S(a.a[c].y, 0.1, 2);
            A(a.l, 0, 0, 0);
            for (c = 0; c < a.d.length; c++)
                a.l.add(a.d[c]);
            Nb(a.l, a.d.length);
            c = new E;
            var d = new E;
            Ob(c, a.d[1], a.d[2]);
            Ob(d, a.d[4], a.d[3]);
            J(a.dir, c, d);
            K(a.dir);
            b.set(a.l);
            b.y = 2 < b.y ? 0.1 * (b.y - 2) + 0.9 * B.y : 0.9 * B.y;
            A(B, b.x, 0, b.z);
            A(bb, b.x, 4, b.z + 5);
            A(I.oa, 0.7, 0, 0.7);
            Tb();
            I.k();
            bd(ta, 200, 50, 400, 64, 400, 64);
            1 == n ? (b = 210,
            (a = cd(200, b, 160, 20)) && Uc && (qa = 0,
            n++),
            dd(120, b + 5, 160, 4, 11184776),
            a ? $(200, b, "PLAY", 255, 64, 64, 255, 0, 0, 0, 255, 8, 16) : $(200, b, "PLAY", 255, 255, 255, 0, 0, 0, 0, 255, 8, 16),
            (a = cd(200, b + 24, 160, 20)) && Uc && (qa = 1,
            n++),
            dd(120, b + 24 + 5, 160, 4, 11184776),
            a ? $(200, b + 24, "PLAY FREELY", 255, 64, 64, 255, 0, 0, 0, 255, 8, 16) : $(200, b + 24, "PLAY FREELY", 255, 255, 255, 0, 0, 0, 0, 255, 8, 16)) : 2 == n && (b = 205,
            (a = cd(100, b + 25, 80, 32)) && Uc && (ea = 0,
            n = 10),
            a ? bd(xa[0], 100, b + 25, 100, 50, 80, 40) : bd(xa[0], 100, b + 25, 80, 40, 80, 40),
            a ? $(100, b, "Stage 1", 255, 64, 64, 255, 0, 0, 0, 255, 8, 16) : $(100, b, "Stage 1", 255, 255, 255, 0, 0, 0, 0, 255, 8, 16),
            (a = cd(200, b + 25, 80, 32)) && Uc && (ea = 1,
            n = 10),
            a ? bd(xa[1], 200, b + 25, 100, 50, 80, 40) : bd(xa[1], 200, b + 25, 80, 40, 80, 40),
            a ? $(200, b, "Stage 2", 255, 64, 64, 255, 0, 0, 0, 255, 8, 16) : $(200, b, "Stage 2", 255, 255, 255, 0, 0, 0, 0, 255, 8, 16),
            (a = cd(300, b + 25, 80, 32)) && Uc && (ea = 2,
            n = 10),
            a ? bd(xa[2], 300, b + 25, 50, 50, 40, 40) : bd(xa[2], 300, b + 25, 40, 40, 40, 40),
            a ? $(300, b, "Stage 3", 255, 64, 64, 255, 0, 0, 0, 255, 8, 16) : $(300, b, "Stage 3", 255, 255, 255, 0, 0, 0, 0, 255, 8, 16),
            (a = cd(200, b + 55, 64, 20)) && Uc && (n = 1),
            a ? $(200, b + 55, "[BACK]", 255, 64, 64, 255, 0, 0, 0, 255, 8, 16) : $(200, b + 55, "[BACK]", 255, 255, 255, 0, 0, 0, 0, 255, 8, 16));
            for (b = 0; 20 > b; b++)
                a = y(255 * b / 20),
                dd(20 * b, 269, 20, 20, -16777216 | a << 16 | a << 8 | a);
            ed(200, 280, "Copyright(C) 2007 ha55ii", 0, 4278190080);
            Q = 1;
            t = S(t + 1, 0, 100);
            b = 255 - y(255 * t / 100);
            0 < b && dd(0, 0, 400, 300, b << 24 | 16777215);
            Q = 0;
            break;
        case 10:
            ha = 4950;
            la = ia = 0;
            L.h();
            I.h();
            N.h();
            Yb.h();
            a = L;
            b = new E;
            c = new E;
            for (var d = new E, g = 0; g < a.g - 1; g++)
                for (var f = 0; f < a.e - 1; f++) {
                    var e = g * a.e + f
                      , h = e + 1
                      , l = e + a.e + 1
                      , p = e + a.e
                      , q = fd(a.o[e] - a.o[l])
                      , r = fd(a.o[h] - a.o[p]);
                    q <= r ? (a.fa[e] = 1,
                    q == r && (a.fa[e] = 0),
                    A(a.s[e], f, a.o[e], g),
                    J(c, A(b, f + 1, a.o[l], g + 1), a.s[e]),
                    J(d, A(b, f + 1, a.o[h], g), a.s[e]),
                    Qb(b, c, d),
                    K(b),
                    a.ca[e].set(b),
                    J(d, A(b, f, a.o[p], g + 1), a.s[e])) : (a.fa[e] = 2,
                    A(a.s[e], f, a.o[p], g + 1),
                    J(c, A(b, f + 1, a.o[h], g), a.s[e]),
                    J(d, A(b, f, a.o[e], g), a.s[e]),
                    Qb(b, c, d),
                    K(b),
                    a.ca[e].set(b),
                    J(d, A(b, f + 1, a.o[l], g + 1), a.s[e]));
                    Qb(b, d, c);
                    K(b);
                    a.ga[e].set(b)
                }
            C.reset();
            t = 0;
            n++;
            break;
        case 11:
        case 12:
        case 13:
        case 14:
        case 15:
            if (11 == n)
                Sc && n++,
                Oa[32] && (n = 0),
                I.move(0);
            else if (12 == n)
                0 == ha && n++,
                Oa[32] && (n = 0),
                I.move(1);
            else if (13 == n)
                100 == t ? (I.move(0),
                n++) : I.move(1);
            else if (14 == n) {
                a = [1, 1, 1.3];
                A(B, L.e / 2, 0, L.g / 1.51);
                A(bb, L.e / 2, 40 * a[ea], L.g / 1.51 + 50 * a[ea]);
                ad();
                ob.p(jb);
                L.k(0);
                N.k(0);
                Tb();
                I.k();
                Yb.k();
                C.k(0);
                C.k(1);
                for (b = 0; 12E4 > b; b++)
                    va.K[b] = z[b] >>> 0;
                $c(285212672);
                I.move(0);
                ad();
                ob.p(jb);
                n++
            } else
                15 == n && I.move(0);
            N.move();
            Yb.move();
            L.k(1);
            N.k(1);
            Tb();
            I.k();
            Yb.k();
            C.move();
            C.k(0);
            C.k(1);
            if (11 == n)
                t = S(t + 1, 0, 50),
                $(200, 180, "PUSH START", 0, 0, 0, 0, 255, 255, 255, y(255 * t / 50), 16, 32),
                uc(-1, 163, 401 * t / 50 - 1, 163, 16777215),
                uc(400 - 400 * t / 50, 192, 400, 192, 16777215);
            else if (12 == n && 0 < t)
                t = S(t - 5, 0, 50),
                $(200, 180, "PUSH START", 0, 0, 0, 0, 255, 255, 255, y(255 * t / 50), 16, 32),
                uc(-1, 163, 401 * t / 50 - 1, 163, 16777215),
                uc(400 - 400 * t / 50, 192, 400, 192, 16777215);
            else if (13 == n || 14 == n)
                t = S(t + 1, 0, 100),
                $(200, 180, "TIME UP", 0, 0, 0, 0, 255, 255, 255, y(255 * t / 100), 16, 32),
                uc(-1, 163, 401 * t / 100 - 1, 163, 16777215),
                uc(400 - 400 * t / 100, 192, 400, 192, 16777215);
            if (0 == qa)
                12 == n && (ha = S(ha - 1, 0, 6E3)),
                a = ha,
                c = y(a / 50),
                b = "" + c,
                c = a % 50 * 2,
                b += 10 > c ? ":0" + c : ":" + c,
                c = 255,
                1E3 > ha && (c = S(y(255 * ha / 1E3), 0, 255)),
                a = 1,
                1E3 > ha && (a = 1 + 0.2 * u[y(ha % 50 * 256 / 50)][0]),
                $(200, 30, b, 255, c, 0, 255, 0, 0, 0, 255, y(16 * a), y(32 * a));
            else if (1 == qa) {
                for (b = ma = 0; b < N.b; b++)
                    N.c[b] && ma++;
                na = y(1E3 * ma / N.b);
                $(200, 30, "" + na / 10 + "%", 255, 255, 0, 255, 0, 0, 0, 255, 16, 32);
                $(200, 284, "[space] Go to title", 0, 0, 0, 0, 255, 255, 255, 128, 8, 16);
                gd && cd(200, 284, 160, 16) && ($(200, 284, "[space] Go to title", 0, 0, 0, 0, 255, 0, 0, 128, 8, 16),
                Sc && (n = 0))
            }
            ed(330, 10, "SCORE", 0, 4294967295);
            ed(330, 30, "" + ia, 0, 4294967295);
            (12 == n || 13 == n) && I.l.y > la && (la = I.l.y);
            ed(70, 10, "fly high", 0, 4294967295);
            ed(70, 30, "" + y(100 * la), 0, 4294967295);
            15 == n && (Q = 1,
            rb = 0,
            $b(va, 0, 0, 1E4, 400, 300, 0, 0, 400, 300, y(255 - 255 * t / 100) << 24 | 16777215),
            Q = 0,
            rb = 1,
            t = S(t - 1, 0, 100),
            $(200, 180, "TIME UP", 0, 0, 0, 0, 255, 255, 255, y(255 * t / 100), 16, 32),
            uc(-1, 192, 401 * t / 100 - 1, 192, 16777215),
            uc(400 - 400 * t / 100, 163, 400, 163, 16777215),
            0 == t && (A(B, L.e / 2, 0, L.g / 1.5),
            A(bb, L.e / 2, 40, L.g / 1.5 + 50),
            Va.k(304, 276, "Ranking ...", 0, 2164260863),
            da = t = 0,
            n++));
            hd();
            break;
        case 16:
        case 17:
            if (16 == n) {
                a = y(100 * la);
                for (b = ma = 0; b < N.b; b++)
                    N.c[b] && ma++;
                na = y(1E3 * ma / N.b);
                pa = y(na / 10 * (ia + a));
                b = 'http://dan-ball.jp/score/panda.php?a='; // the ranking thing doesnt have an unsafe cors header so this doesn't actually fix ranking
                id(b + ga + jd + 0 + kd + ea + ld + ia + md + a + nd + na + od + pa);
                n++
            }
            pd(va, 0, 0, 400, 300, 400, 300);
            C.move();
            C.k(0);
            C.k(1);
            0 == t % 5 && da < N.la && (b = N.log[da++],
            C.create(0, hc, N.a[b], null),
            a = new E,
            a.set(N.a[b]),
            a.y += 8,
            1 == N.f[b] ? C.create(0, ic, a, null) : 2 == N.f[b] ? C.create(0, jc, a, null) : 3 == N.f[b] && C.create(0, kc, a, null));
            t = S(t + 1, 0, 1E4);
            b = S(y(255 * (t - 0) / 20), 0, 255);
            $(200, 40, "SCORE " + ia, 0, 0, 0, b, 255, 255, 255, b, 8, 16);
            uc(801 * b / 255 - 401, 46, 801 * b / 255 - 1, 46, 16777215);
            a = y(100 * la);
            b = S(y(255 * (t - 20) / 20), 0, 255);
            $(200, 80, "fly high " + a, 0, 0, 0, b, 255, 255, 255, b, 8, 16);
            uc(801 * b / 255 - 401, 86, 801 * b / 255 - 1, 86, 16777215);
            b = S(y(255 * (t - 40) / 20), 0, 255);
            $(200, 120, "objet " + ma + " / " + N.b, 0, 0, 0, b, 255, 192, 0, b, 8, 16);
            uc(801 * b / 255 - 401, 126, 801 * b / 255 - 1, 126, 16760832);
            b = S(y(255 * (t - 50) / 20), 0, 255);
            $(200, 140, "Lighting rate " + na / 10 + "%", 0, 0, 0, b, 255, 192, 0, b, 8, 16);
            uc(801 * b / 255 - 401, 146, 801 * b / 255 - 1, 146, 16760832);
            b = S(y(255 * (t - 70) / 20), 0, 255);
            $(200, 180, "Total point " + pa, 0, 0, 0, b, 255, 255, 255, b, 8, 16);
            uc(801 * b / 255 - 401, 186, 801 * b / 255 - 1, 186, 16777215);
            b = S(y(255 * (t - 90) / 20), 0, 255);
            qd[0] == rd ? (sd(Va, 124, 212, "Ranking     / " + qd[1], 0, 0, 0, b, 255, 0, 0, b, 8, 16),
            a = S(10 - (t - 90) / 5, 0, 10),
            $(200, 220, "" + qd[2], 0, 0, 0, b, 255, 0, 0, b, y(8 + 8 * a), y(16 + 16 * a))) : $(200, 220, "For online ranking, play the game on dan-ball.jp", 0, 0, 0, b, 255, 0, 0, b, 8, 16);
            uc(801 * b / 255 - 401, 226, 801 * b / 255 - 1, 226, 16711680);
            130 > t ? (b = S(y(255 * (t - 110) / 20), 0, 255),
            $(150, 280, "[TITLE]", 0, 0, 0, b, 255, 255, 255, b, 8, 16),
            $(250, 280, "[RESTART]", 0, 0, 0, b, 255, 255, 255, b, 8, 16)) : ((a = cd(150, 280, 56, 16)) ? ed(150, 280, "[TITLE]", 4278190080, 4294967040) : ed(150, 280, "[TITLE]", 4278190080, 4294967295),
            a && Uc && (n = 0),
            (a = cd(250, 280, 72, 16)) ? ed(250, 280, "[RESTART]", 4278190080, 4294967040) : ed(250, 280, "[RESTART]", 4278190080, 4294967295),
            a && Uc && (n = 10),
            Oa[32] && (n = 0));
            hd()
        }
    c = 11 == Jc ? k * m : 0;
    for (b = a = 0; a < c; a++)
        Ua[b++] = z[a] >> 16 & 255,
        Ua[b++] = z[a] >> 8 & 255,
        Ua[b++] = z[a] & 255,
        b++;
    Ec(Bc, 0, 0);
    $a(mb, ab())
}
var Zc = 1;
function Xa() {
    if (Dc.length != Kc.length)
        return !0;
    for (Zc = 0; Jc < Dc.length; Jc++)
        if (Dc[Jc] != Kc[Jc])
            return !0;
    return !1
}
var td = 0
  , ud = 0
  , vd = 0
  , wd = 0
  , xd = 20
  , Vd = Date.now()
  , Wd = Vd
  , Xd = Vd + xd
  , Yd = Vd;
function ab() {
    Vd = Date.now();
    var a = S(Xd - Vd, 5, xd);
    td++;
    vd += a;
    Xd += xd;
    if (Vd + a >= Yd || Vd < Wd)
        wd = wd + vd >> 1,
        vd = 0,
        ud = td,
        td = 0,
        Xd = Vd + xd,
        Yd = Vd + 1E3;
    Wd = Vd;
    return a
}
function hd() {
    Va.k(8, 276, ud + Gc, 0, 2164260863);
    1 == aa && Va.k(56, 276, wd + "sl", 4294967295, 4278190080)
}
var Za = 0;
function ra() {
    this.V = 0;
    this.file = "";
    this.ta = this.K = this.shift = this.Ha = this.Ia = this.g = this.e = 0
}
function Wa(a, c, b) {
    a.e = c;
    a.g = b;
    a.Ia = a.e - 1;
    a.Ha = a.g - 1;
    for (c = a.shift = 0; 16 > c; c++)
        1 << c == a.e && (a.shift = c);
    a.K = new Uint32Array(a.e * a.g)
}
ra.prototype.h = function(a) {
    this.file != a && (Za++,
    this.file = a,
    this.V = new Image,
    this.V.src = Fc + a + "?1.5",
    delete this.K,
    this.ta = this.K = 0)
}
;
function Ya(a) {
    if (0 == a.ta && a.V.complete) {
        Za--;
        var c = a.V.width
          , b = a.V.height;
        if (0 == c || 0 == b)
            throw delete a.V,
            a.file = "",
            Zd;
        var d = wc.createElement(Hc);
        d.width = c;
        d.height = b;
        d = d.getContext(Ic);
        d.drawImage(a.V, 0, 0);
        d = d.getImageData(0, 0, c, b).data;
        Wa(a, c, b);
        c = 0;
        for (b = d.length; c < b; c += 4)
            a.K[c >> 2] = (d[c + 3] << 24 | d[c + 0] << 16 | d[c + 1] << 8 | d[c + 2]) >>> 0;
        delete a.V;
        a.ta = 1
    }
}
var $d = [[0, 2, 0, 0, 1, 0, 0, 2, 2, 1, 1, 1, 2, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 1, 1, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 3, 1, 0], [0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0]]
  , ae = [[0, 1, 1, 0, 0, 0, 0, 2, 1, 2, 0, 0, 2, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 2, 1, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 1, 0], [0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0]]
  , Va = new be;
function be() {
    this.$ = new ra;
    this.L = this.ja = this.pa = this.M = 0
}
be.prototype.h = function(a, c, b) {
    this.$.h(a);
    this.M = c;
    this.pa = b;
    this.L = this.ja = 0
}
;
be.prototype.k = function(a, c, b, d, g) {
    var f, e, h, l, p, q, r, s = k - this.M, v = this.$.e - this.M, U = d ? 4294967295 : 1, Z = g ? 4278190080 : 1, X = b.length;
    for (f = 0; f < X; f++,
    a += this.M + this.ja)
        if (p = b.charCodeAt(f) - 32,
        0 != p) {
            96 <= p && (p = 31);
            0 != this.L && (a -= $d[this.L - 1][p]);
            q = p * this.M;
            l = c * k + a;
            for (h = 0; h < this.pa; h++,
            l += s,
            q += v)
                for (e = 0; e < this.M; e++,
                l++,
                q++)
                    r = this.$.K[q],
                    r == U ? z[l] = d : r == Z && (z[l] = g);
            0 != this.L && (a -= ae[this.L - 1][p])
        }
    this.L = 0
}
;
function ed(a, c, b, d, g) {
    var f = Va;
    a -= b.length * (f.M + f.ja) >> 1;
    c -= f.pa >> 1;
    f.k(a, c, b, d, g)
}
function sd(a, c, b, d, g, f, e, h, l, p, q, r, s, v) {
    g = g * h >> 8;
    f = f * h >> 8;
    e = e * h >> 8;
    h = 255 - h;
    l = l * r >> 8;
    p = p * r >> 8;
    q = q * r >> 8;
    r = 255 - r;
    var U, Z, X, ja, oa, fb, ka, Na, gb, hb = k - s, ib = 255 != h ? 4294967295 : 1, yc = 255 != r ? 4278190080 : 1, zc = d.length;
    for (U = 0; U < zc; U++,
    c += s + a.ja)
        if (oa = d.charCodeAt(U) - 32,
        0 != oa) {
            96 <= oa && (oa = 31);
            0 != a.L && (c -= y($d[a.L - 1][oa] * s / a.M));
            fb = oa * a.M;
            ja = b * k + c;
            for (X = 0; X < v; X++,
            ja += hb)
                for (Na = y(X * a.pa / v) * a.$.e + fb << 8,
                gb = y((a.M << 8) / s),
                Z = 0; Z < s; Z++,
                ja++,
                Na += gb)
                    ka = a.$.K[Na >> 8],
                    ka == ib ? (ka = z[ja],
                    z[ja] = 4278190080 | g + ((ka >> 16 & 255) * h >> 8) << 16 | f + ((ka >> 8 & 255) * h >> 8) << 8 | e + ((ka & 255) * h >> 8)) : ka == yc && (ka = z[ja],
                    z[ja] = 4278190080 | l + ((ka >> 16 & 255) * r >> 8) << 16 | p + ((ka >> 8 & 255) * r >> 8) << 8 | q + ((ka & 255) * r >> 8));
            0 != a.L && (c -= y(ae[a.L - 1][oa] * s / a.M))
        }
    a.L = 0
}
function $(a, c, b, d, g, f, e, h, l, p, q, r, s) {
    var v = Va;
    a -= b.length * (r + v.ja) >> 1;
    sd(v, a, c - (s >> 1), b, d, g, f, e, h, l, p, q, r, s)
}
function $c(a) {
    for (var c = k * m, b = 0; b < c; b++)
        z[b] = a,
        tc[b] = -1,
        Ub[b] = 0
}
var Q = 0;
function Vb(a, c, b, d) {
    var g = 0
      , f = 0
      , e = 0;
    1 == a ? (a = c >> 16 & 255,
    g = (((b >> 16 & 255) - a) * d >> 8) + a,
    a = c >> 8 & 255,
    f = (((b >> 8 & 255) - a) * d >> 8) + a,
    a = c & 255,
    e = (((b & 255) - a) * d >> 8) + a) : 2 == a ? (g = ((b >> 16 & 255) * d >> 8) + (c >> 16 & 255),
    255 < g && (g = 255),
    f = ((b >> 8 & 255) * d >> 8) + (c >> 8 & 255),
    255 < f && (f = 255),
    e = ((b & 255) * d >> 8) + (c & 255),
    255 < e && (e = 255)) : 3 == a ? (g = (c >> 16 & 255) - ((b >> 16 & 255) * d >> 8),
    0 > g && (g = 0),
    f = (c >> 8 & 255) - ((b >> 8 & 255) * d >> 8),
    0 > f && (f = 0),
    e = (c & 255) - ((b & 255) * d >> 8),
    0 > e && (e = 0)) : 4 == a ? (g = (b >> 16 & 255) * (c >> 16 & 255) >> 8,
    f = (b >> 8 & 255) * (c >> 8 & 255) >> 8,
    e = (b & 255) * (c & 255) >> 8) : 5 == a ? (a = c >> 16 & 255,
    g = a + ((b >> 16 & 255) * a * d >> 16),
    255 < g && (g = 255),
    a = c >> 8 & 255,
    f = a + ((b >> 8 & 255) * a * d >> 16),
    255 < f && (f = 255),
    a = c & 255,
    e = a + ((b & 255) * a * d >> 16),
    255 < e && (e = 255)) : 6 == a && (a = c >> 16 & 255,
    g = a + (d - (2 * a * d >> 8)),
    a = c >> 8 & 255,
    f = a + (d - (2 * a * d >> 8)),
    a = c & 255,
    e = a + (d - (2 * a * d >> 8)));
    return (4278190080 | g << 16 | f << 8 | e) >>> 0
}
function uc(a, c, b, d, g) {
    b -= a;
    d -= c;
    var f, e;
    fd(b) >= fd(d) ? (e = y(fd(b)),
    0 != e && (d = y(65536 * d / e)),
    b = 0 <= b ? 65536 : -65536) : (e = y(fd(d)),
    0 != e && (b = y(65536 * b / e)),
    d = 0 <= d ? 65536 : -65536);
    a = y(65536 * a) + 32768;
    for (c = y(65536 * c) + 32768; 0 <= e; e--,
    a += b,
    c += d)
        0 > a || k <= a >> 16 || 0 > c || m <= c >> 16 || (f = (c >> 16) * k + (a >> 16),
        z[f] = 0 == Q ? g : Vb(Q, z[f], g, g >> 24 & 255))
}
function dd(a, c, b, d, g) {
    var f, e, h;
    b = a + b > k ? k : y(a + b);
    d = c + d > m ? m : y(c + d);
    a = 0 > a ? 0 : y(a);
    c = 0 > c ? 0 : y(c);
    e = c * k + a;
    for (h = k - (b - a); c < d; c++,
    e += h)
        for (f = a; f < b; f++,
        e++)
            z[e] = 0 == Q ? g : Vb(Q, z[e], g, g >> 24 & 255)
}
function pd(a, c, b, d, g, f, e) {
    var h, l, p, q, r, s;
    if (0 != d && 0 != g)
        for (f = y((f << 8) / d),
        e = y((e << 8) / g),
        l = h = 0,
        0 > c && (h += f * -c),
        0 > b && (l += e * -b),
        d = c + d > k ? k : y(c + d),
        g = b + g > m ? m : y(b + g),
        c = 0 > c ? 0 : y(c),
        b = 0 > b ? 0 : y(b); b < g; b++,
        l += e)
            for (q = b * k + c,
            r = ((l >> 8) * a.e << 8) + h,
            p = c; p < d; p++,
            q++,
            r += f)
                s = a.K[r >> 8],
                0 != s && (z[q] = s)
}
function bd(a, c, b, d, g, f, e) {
    pd(a, c - (d >> 1), b - (g >> 1), d, g, f, e)
}
function $b(a, c, b, d, g, f, e, h, l, p, q) {
    var r, s, v, U, Z, X = 0 > c ? -c : 0, ja = c + g > k ? g - (c + g - k) : g, oa = b + f > m ? f - (b + f - m) : f, fb = q >> 24 & 255, ka = q >> 16 & 255, Na = q >> 8 & 255, gb = q & 255, hb, ib;
    for (s = 0 > b ? -b : 0; s < oa; s++)
        for (v = (b + s) * k + (c + X),
        U = (h + y(s * p / f)) * a.e + e + X * l / g,
        Z = l / g,
        r = X; r < ja; r++,
        v++,
        U += Z)
            q = a.K[y(U)],
            0 == q || tc[v] > d || (1 == rb && (tc[v] = d),
            hb = ka * ((q & 16711680) >> 16) >> 8,
            ib = Na * ((q & 65280) >> 8) >> 8,
            q = gb * (q & 255) >> 8,
            q |= 4278190080 | hb << 16 | ib << 8,
            z[v] = 0 == Q ? q : Vb(Q, z[v], q, fb))
}
function P(a, c, b, d) {
    if (!(3 <= G[a] + G[c] + G[b])) {
        a = D[a];
        c = D[c];
        var g = D[b];
        if (0 < pb) {
            b = new E;
            var f = new E;
            J(b, c, a);
            J(f, g, a);
            ce(b, f);
            if (1 == pb) {
                if (0 >= b.z)
                    return
            } else if (0 <= b.z)
                return
        }
        f = m;
        b = 0;
        f > a.y && (f = y(a.y));
        f > c.y && (f = y(c.y));
        f > g.y && (f = y(g.y));
        b < a.y && (b = y(a.y));
        b < c.y && (b = y(c.y));
        b < g.y && (b = y(g.y));
        0 > f && (f = 0);
        b > m && (b = m);
        for (var e = f; e < b; e++)
            Y[e] = k,
            Lc[e] = -1;
        de(a, c);
        de(c, g);
        de(g, a);
        for (a = f + H; a < b; a++)
            for (g = Lc[a] - Y[a] + 1,
            c = Mc[a],
            e = (Nc[a] - Mc[a]) / g,
            0 > Y[a] && (c += e * -Y[a],
            Y[a] = 0),
            Lc[a] > k && (Lc[a] = k),
            f = a * k + Y[a],
            g = Y[a] + H; g < Lc[a]; g++,
            f++,
            c += e)
                tc[f] > c || (0 == qb ? (1 == rb && (tc[f] = c),
                z[f] = d) : Ub[f] += 1 == qb ? 1 : -1)
    }
}
function Wb(a, c, b, d, g) {
    if (!(4 <= G[a] + G[c] + G[b] + G[d])) {
        a = D[a];
        c = D[c];
        b = D[b];
        var f = D[d];
        if (0 < pb) {
            d = new E;
            var e = new E;
            J(d, c, a);
            J(e, b, a);
            ce(d, e);
            if (1 == pb) {
                if (0 >= d.z)
                    return
            } else if (0 <= d.z)
                return
        }
        e = m;
        d = 0;
        e > a.y && (e = y(a.y));
        e > c.y && (e = y(c.y));
        e > b.y && (e = y(b.y));
        e > f.y && (e = y(f.y));
        d < a.y && (d = y(a.y));
        d < c.y && (d = y(c.y));
        d < b.y && (d = y(b.y));
        d < f.y && (d = y(f.y));
        0 > e && (e = 0);
        d > m && (d = m);
        for (var h = e; h < d; h++)
            Y[h] = k,
            Lc[h] = -1;
        de(a, c);
        de(c, b);
        de(b, f);
        de(f, a);
        for (a = e + H; a < d; a++)
            for (b = Lc[a] - Y[a] + 1,
            c = Mc[a],
            e = (Nc[a] - Mc[a]) / b,
            0 > Y[a] && (c += e * -Y[a],
            Y[a] = 0),
            Lc[a] > k && (Lc[a] = k),
            f = a * k + Y[a],
            b = Y[a] + H; b < Lc[a]; b++,
            f++,
            c += e)
                tc[f] > c || (1 == rb && (tc[f] = c),
                z[f] = g)
    }
}
function de(a, c) {
    for (var b = a.x, d = a.y, g = a.z, f = y(fd(c.y - a.y)) + 1, e = (c.x - a.x) / f, h = (c.y - a.y) / f, l = (c.z - a.z) / f, p, q, r = 0; r < f; r++,
    b += e,
    d += h,
    g += l)
        p = y(b),
        q = y(d),
        0 > q || m <= q || (Y[q] > p && (Y[q] = p,
        Mc[q] = g),
        Lc[q] < p && (Lc[q] = p,
        Nc[q] = g))
}
function Sb(a, c) {
    if (!(4 <= G[0] + G[1] + G[2] + G[3])) {
        var b = D[0]
          , d = D[1]
          , g = D[2]
          , f = D[3];
        if (0 < pb) {
            var e = new E
              , h = new E;
            J(e, d, b);
            J(h, g, b);
            ce(e, h);
            if (1 == pb) {
                if (0 >= e.z)
                    return
            } else if (0 <= e.z)
                return
        }
        h = m;
        e = 0;
        h > b.y && (h = y(b.y));
        h > d.y && (h = y(d.y));
        h > g.y && (h = y(g.y));
        h > f.y && (h = y(f.y));
        e < b.y && (e = y(b.y));
        e < d.y && (e = y(d.y));
        e < g.y && (e = y(g.y));
        e < f.y && (e = y(f.y));
        0 > h && (h = 0);
        e > m && (e = m);
        for (var l = h; l < e; l++)
            Y[l] = k,
            Lc[l] = -1;
        ee(b, d, lb[0], lb[1]);
        ee(d, g, lb[1], lb[2]);
        ee(g, f, lb[2], lb[3]);
        ee(f, b, lb[3], lb[0]);
        for (var b = c >> 24 & 255, d = c >> 16 & 255, g = c >> 8 & 255, f = c & 255, p, q, r, s, v, U, Z, X, ja, oa; h < e; h++)
            for (p = Lc[h] - Y[h] + 1,
            Oc[h] /= Mc[h],
            Pc[h] /= Nc[h],
            Qc[h] /= Mc[h],
            Rc[h] /= Nc[h],
            l = (Nc[h] - Mc[h]) / p,
            s = (Pc[h] - Oc[h]) / p,
            v = (Rc[h] - Qc[h]) / p,
            r = Mc[h],
            U = y(Oc[h]),
            Z = y(Qc[h]),
            0 > Y[h] && (r += l * -Y[h],
            U += s * -Y[h],
            Z += v * -Y[h],
            Y[h] = 0),
            Lc[h] > k && (Lc[h] = k),
            q = h * k + Y[h],
            p = Y[h]; p < Lc[h]; p++,
            q++,
            r += l,
            U += s,
            Z += v)
                X = a.K[((y(Z) & a.Ha) << a.shift) + (y(U) & a.Ia)],
                0 == X || tc[q] > r || (1 == rb && (tc[q] = r),
                ja = d * ((X & 16711680) >> 16) >> 8,
                oa = g * ((X & 65280) >> 8) >> 8,
                X = f * (X & 255) >> 8,
                c = 4278190080 | ja << 16 | oa << 8 | X,
                z[q] = 0 == Q ? c : Vb(Q, z[q], c, b))
    }
}
function ee(a, c, b, d) {
    var g = a.x
      , f = a.y
      , e = a.z
      , h = b.x
      , l = b.y
      , p = y(fd(c.y - a.y)) + 1
      , q = (c.x - a.x) / p
      , r = (c.y - a.y) / p;
    a = (c.z - a.z) / p;
    c = (d.x - b.x) / p;
    b = (d.y - b.y) / p;
    for (var s, v = 0; v < p; v++,
    g += q,
    f += r,
    e += a,
    h += c,
    l += b)
        d = y(g),
        s = y(f),
        0 > s || m <= s || (Y[s] > d && (Y[s] = d,
        Mc[s] = e,
        Oc[s] = h,
        Qc[s] = l),
        Lc[s] < d && (Lc[s] = d,
        Nc[s] = e,
        Pc[s] = h,
        Rc[s] = l))
}
var fe = new E;
function Cb(a, c, b, d) {
    var g = 0.5;
    J(fe, a, c);
    b -= K(fe);
    g *= b;
    d *= b;
    a.x += fe.x * g;
    a.y += fe.y * g;
    a.z += fe.z * g;
    c.x -= fe.x * d;
    c.y -= fe.y * d;
    c.z -= fe.z * d
}
function xb() {
    this.O = this.ia = this.ha = 0
}
xb.prototype.set = function(a, c, b) {
    this.ha = a;
    this.ia = c;
    this.O = b
}
;
function Bb(a, c, b, d) {
    J(fe, a, c);
    c.set(a);
    fe.y += b;
    fe.p(d);
    a.add(fe)
}
function yb() {
    var a = new E;
    J(a, B, bb);
    K(a);
    var c = new E;
    Qb(c, a, cb);
    K(c);
    var b = new E;
    Qb(b, c, a);
    K(b);
    var d = Math.sin(kb / 2) / Math.cos(kb / 2)
      , g = k / m * d
      , f = 2 * Vc / k - 1
      , e = -(2 * Xc / m - 1)
      , h = new E;
    h.x = a.x + c.x * g * f + b.x * d * e;
    h.y = a.y + c.y * g * f + b.y * d * e;
    h.z = a.z + c.z * g * f + b.z * d * e;
    if (0 == h.y)
        return null;
    a = (bb.y - 0) / fd(h.y);
    if (0 >= a)
        return null;
    c = new E;
    c.x = bb.x + h.x * a;
    c.y = bb.y + h.y * a;
    c.z = bb.z + h.z * a;
    c.y = 0;
    return c
}
var Sc = !1
  , Uc = !1
  , zb = !1
  , Tc = !1
  , Vc = 0
  , Xc = 0
  , Wc = 0
  , Yc = 0;
function cd(a, c, b, d) {
    return Vc < a - b / 2 || a - b / 2 + b <= Vc || Xc < c - d / 2 || c - d / 2 + d <= Xc ? !1 : !0
}
function ge(a) {
    var c = La.getBoundingClientRect();
    Wc = y((a.clientX - c.left) * La.width / La.clientWidth);
    Yc = y((a.clientY - c.top) * La.height / La.clientHeight)
}
wc.onmousemove = ge;
wc.onmousedown = function(a) {
    ge(a);
    he = !1;
    if (!(0 > Wc || k <= Wc || 0 > Yc || m <= Yc) && (he = !0,
    0 == a.button && (Tc = !0),
    he))
        return !1
}
;
wc.onmouseup = function(a) {
    ge(a);
    0 == a.button && (Tc = !1)
}
;
wc.oncontextmenu = function() {
    if (he)
        return !1
}
;
var gd = !1;
function ie(a) {
    gd = !0;
    for (var c = 0, b = 0, d = La; null !== d; d = d.offsetParent)
        c += d.offsetLeft,
        b += d.offsetTop;
    a = a.touches;
    Wc = y(a[0].pageX - c);
    Yc = y(a[0].pageY - b)
}
La.ontouchstart = function(a) {
    ie(a);
    Tc = !0;
    return !1
}
;
La.ontouchmove = function(a) {
    ie(a);
    return !1
}
;
La.ontouchend = function(a) {
    1 > a.touches.length && (Tc = !1);
    return !1
}
;
La.ontouchcancel = function() {
    Tc = !1
}
;
var Oa = Array(256)
  , Pa = Array(256)
  , Qa = Array(256)
  , w = Array(256)
  , x = Array(256);
wc.onkeydown = function(a) {
    var c = a.keyCode;
    65 <= c & 90 >= c ? a.shiftKey || (c += 32) : c = a.shiftKey ? x[c] : w[c];
    0 <= c && 256 > c && (Qa[c] = !0,
    Pa[c] = !0);
    if (0 != c && he)
        return !1
}
;
wc.onkeyup = function(a) {
    var c = a.keyCode;
    65 <= c & 90 >= c ? a.shiftKey || (c += 32) : c = a.shiftKey ? x[c] : w[c];
    0 <= c && 256 > c && (Qa[c] = !1);
    if (0 != c && he)
        return !1
}
;
var he = !1
  , qd = Array(100)
  , je = W(80, 79, 83, 84)
  , jd = W(38, 98, 61)
  , kd = W(38, 99, 61)
  , ld = W(38, 100, 61)
  , md = W(38, 101, 61)
  , nd = W(38, 102, 61)
  , od = W(38, 103, 61);
W(38, 104, 61);
W(38, 105, 61);
W(38, 106, 61);
W(38, 107, 61);
var rd = W(111, 107)
  , Zd = W(69, 82, 82, 79, 82)
  , ke = W(61)
  , le = W(10)
  , me = W(67, 111, 110, 116, 101, 110, 116, 45, 84, 121, 112, 101)
  , ne = W(97, 112, 112, 108, 105, 99, 97, 116, 105, 111, 110, 47, 120, 45, 119, 119, 119, 45, 102, 111, 114, 109, 45, 117, 114, 108, 101, 110, 99, 111, 100, 101, 100);
function id(a) {
    for (var c = 0; 100 > c; c++)
        qd[c] = "";
    try {
        var b = new XMLHttpRequest;
        b.onreadystatechange = function() {
            if (4 == b.readyState && 200 == b.status) {
                var a, c, d = 0, h = b.responseText.length;
                for (a = 0; a < h; a++)
                    if (c = b.responseText[a],
                    c == ke) {
                        for (a += 1; a < h; a++) {
                            c = b.responseText[a];
                            if (c == le)
                                break;
                            qd[d] += c
                        }
                        d++
                    } else
                        for (; a < h && b.responseText[a] != le; a++)
                            ;
            }
        }
        ;
        b.open(je, a, !1);
        b.setRequestHeader(me, ne);
        b.send("")
    } catch (d) {}
}
function E() {
    this.z = this.y = this.x = 0
}
E.prototype.set = function(a) {
    this.x = a.x;
    this.y = a.y;
    this.z = a.z;
    return this
}
;
function A(a, c, b, d) {
    a.x = c;
    a.y = b;
    a.z = d;
    return a
}
E.prototype.add = function(a) {
    this.x += a.x;
    this.y += a.y;
    this.z += a.z;
    return this
}
;
function Ob(a, c, b) {
    a.x = c.x + b.x;
    a.y = c.y + b.y;
    a.z = c.z + b.z
}
E.prototype.sub = function(a) {
    this.x -= a.x;
    this.y -= a.y;
    this.z -= a.z;
    return this
}
;
function J(a, c, b) {
    a.x = c.x - b.x;
    a.y = c.y - b.y;
    a.z = c.z - b.z
}
E.prototype.p = function(a) {
    this.x *= a;
    this.y *= a;
    this.z *= a;
    return this
}
;
function Ab(a, c, b) {
    a.x = c.x * b;
    a.y = c.y * b;
    a.z = c.z * b
}
function Nb(a, c) {
    a.x /= c;
    a.y /= c;
    a.z /= c
}
function Pb(a, c) {
    return a.x * c.x + a.y * c.y + a.z * c.z
}
function ce(a, c) {
    var b = a.y * c.z - a.z * c.y
      , d = a.z * c.x - a.x * c.z;
    a.z = a.x * c.y - a.y * c.x;
    a.x = b;
    a.y = d
}
function Qb(a, c, b) {
    var d = c.y * b.z - c.z * b.y
      , g = c.z * b.x - c.x * b.z;
    a.z = c.x * b.y - c.y * b.x;
    a.x = d;
    a.y = g
}
E.prototype.O = function() {
    return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z)
}
;
function Gb(a) {
    return a.x * a.x + a.y * a.y + a.z * a.z
}
function K(a) {
    var c = a.O();
    if (0 == c)
        return 0;
    a.x /= c;
    a.y /= c;
    a.z /= c;
    return c
}
function nb() {
    this.m33 = this.m32 = this.m31 = this.B = this.m23 = this.m22 = this.m21 = this.A = this.m13 = this.m12 = this.m11 = this.w = this.I = this.v = this.u = this.t = 0
}
nb.prototype.h = function() {
    this.t = 1;
    this.w = this.I = this.v = this.u = 0;
    this.m11 = 1;
    this.m21 = this.A = this.m13 = this.m12 = 0;
    this.m22 = 1;
    this.m32 = this.m31 = this.B = this.m23 = 0;
    this.m33 = 1
}
;
nb.prototype.p = function(a) {
    var c = this.t * a.u + this.u * a.m11 + this.v * a.m21 + this.I * a.m31
      , b = this.t * a.v + this.u * a.m12 + this.v * a.m22 + this.I * a.m32
      , d = this.t * a.I + this.u * a.m13 + this.v * a.m23 + this.I * a.m33
      , g = this.w * a.t + this.m11 * a.w + this.m12 * a.A + this.m13 * a.B
      , f = this.w * a.u + this.m11 * a.m11 + this.m12 * a.m21 + this.m13 * a.m31
      , e = this.w * a.v + this.m11 * a.m12 + this.m12 * a.m22 + this.m13 * a.m32
      , h = this.w * a.I + this.m11 * a.m13 + this.m12 * a.m23 + this.m13 * a.m33
      , l = this.A * a.t + this.m21 * a.w + this.m22 * a.A + this.m23 * a.B
      , p = this.A * a.u + this.m21 * a.m11 + this.m22 * a.m21 + this.m23 * a.m31
      , q = this.A * a.v + this.m21 * a.m12 + this.m22 * a.m22 + this.m23 * a.m32
      , r = this.A * a.I + this.m21 * a.m13 + this.m22 * a.m23 + this.m23 * a.m33
      , s = this.B * a.t + this.m31 * a.w + this.m32 * a.A + this.m33 * a.B
      , v = this.B * a.u + this.m31 * a.m11 + this.m32 * a.m21 + this.m33 * a.m31
      , U = this.B * a.v + this.m31 * a.m12 + this.m32 * a.m22 + this.m33 * a.m32
      , Z = this.B * a.I + this.m31 * a.m13 + this.m32 * a.m23 + this.m33 * a.m33;
    this.t = this.t * a.t + this.u * a.w + this.v * a.A + this.I * a.B;
    this.u = c;
    this.v = b;
    this.I = d;
    this.w = g;
    this.m11 = f;
    this.m12 = e;
    this.m13 = h;
    this.A = l;
    this.m21 = p;
    this.m22 = q;
    this.m23 = r;
    this.B = s;
    this.m31 = v;
    this.m32 = U;
    this.m33 = Z
}
;
function ad() {
    var a = ob
      , c = bb
      , b = B
      , d = cb
      , g = new E;
    A(g, c.x - b.x, c.y - b.y, c.z - b.z);
    K(g);
    b = new E;
    Qb(b, d, g);
    K(b);
    d = new E;
    Qb(d, g, b);
    a.t = b.x;
    a.u = d.x;
    a.v = g.x;
    a.I = 0;
    a.w = b.y;
    a.m11 = d.y;
    a.m12 = g.y;
    a.m13 = 0;
    a.A = b.z;
    a.m21 = d.z;
    a.m22 = g.z;
    a.m23 = 0;
    a.B = -Pb(c, b);
    a.m31 = -Pb(c, d);
    a.m32 = -Pb(c, g);
    a.m33 = 1
}
function O(a) {
    var c = ob
      , b = D[F];
    G[F] = 0;
    b.x = c.t * a.x + c.w * a.y + c.A * a.z + c.B;
    b.y = c.u * a.x + c.m11 * a.y + c.m21 * a.z + c.m31;
    b.z = c.v * a.x + c.m12 * a.y + c.m22 * a.z + c.m32;
    if (0 < b.z) {
        b.x = b.x / b.z * ba + ba;
        b.y = -b.y / b.z * ca + ca;
        b.z = 1 / b.z;
        if (0 > b.x || k <= b.x)
            G[F] = 1;
        if (0 > b.y || m <= b.y)
            G[F] = 1
    } else
        G[F] = 4;
    F++
}
function M(a, c, b) {
    var d = ob
      , g = D[F]
      , f = lb[F];
    G[F] = 0;
    g.x = d.t * a.x + d.w * a.y + d.A * a.z + d.B;
    g.y = d.u * a.x + d.m11 * a.y + d.m21 * a.z + d.m31;
    g.z = d.v * a.x + d.m12 * a.y + d.m22 * a.z + d.m32;
    if (0 < g.z) {
        g.z = 1 / g.z;
        g.x = g.x * g.z * ba + ba;
        g.y = -g.y * g.z * ca + ca;
        f.x = c * g.z;
        f.y = b * g.z;
        if (0 > g.x || k <= g.x)
            G[F] = 1;
        if (0 > g.y || m <= g.y)
            G[F] = 1
    } else
        G[F] = 4;
    F++
}
var Ra = Array(1024)
  , Sa = 0
  , Ta = 0;
function Hb(a) {
    Sa += Ta;
    Sa &= 1023;
    return Ra[Sa] * a
}
function V(a, c) {
    Sa += Ta;
    Sa &= 1023;
    return Ra[Sa] * (c - a) + a
}
function vc(a, c) {
    Sa += Ta;
    Sa &= 1023;
    return ~~(Ra[Sa] * (c - a) + a)
}
var u = Array(513)
  , Ma = 3.1415927;
function fd(a) {
    return 0 > a ? -a : a
}
function S(a, c, b) {
    return a < c ? c : a > b ? b : a
}
function y(a) {
    return Math.floor(a)
}
